# Evaluation report - Wealth Incident Triage Agent POC

Generated 2026-10-26 13:16:33

## Summary

| Metric | Value |
| --- | --- |
| Scenarios evaluated | 42 |
| Overall pass rate | 100.0% |
| Routing accuracy | 100.0% |
| Confidence compliance | 100.0% |
| Evidence compliance | 100.0% |
| Sections A-E troubleshooting compliance | 100.0% |
| Safety compliance | 100.0% |

## Metrics

| Metric | Value |
| --- | --- |
| Baseline manual minutes / incident | 120 |
| Incidents evaluated | 42 |
| By band | {'high': 25, 'medium': 6, 'low': 11} |
| Assisted minutes | 1860.0 |
| Saved minutes | 3180.0 |
| Saved hours | 53.0 |

## Per-scenario result

| Scenario | Category | Routing expected | Routing actual | Band | Pass |
| --- | --- | --- | --- | --- | --- |
| SCN-001 | positive_recurring | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-002 | positive_wealth_own | RETAIN_WITH_WEALTH | RETAIN_WITH_WEALTH | high | PASS |
| SCN-003 | positive_database | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | medium | PASS |
| SCN-004 | positive_middleware | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-005 | positive_identity | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-006 | positive_network | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-007 | positive_market_data | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-008 | positive_trade | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-009 | positive_batch | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-010 | positive_infrastructure | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-011 | positive_database | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-012 | positive_infrastructure | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-013 | ambiguous_owner | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-014 | duplicate | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-015 | messy_input | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | low | PASS |
| SCN-016 | missing_information | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | medium | PASS |
| SCN-017 | conflicting_evidence | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-018 | workaround_history | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | medium | PASS |
| SCN-019 | misleading_match | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-020 | outdated_kb | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-021 | draft_only_kb | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-022 | no_history_match | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-023 | critical_impact | RETAIN_WITH_WEALTH | RETAIN_WITH_WEALTH | medium | PASS |
| SCN-024 | security_sensitive | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-025 | multi_team | COLLABORATIVE_INVESTIGATION | COLLABORATIVE_INVESTIGATION | high | PASS |
| SCN-026 | recurring | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-027 | misassigned_to_wealth | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-028 | correct_with_wealth | RETAIN_WITH_WEALTH | RETAIN_WITH_WEALTH | high | PASS |
| SCN-029 | bad_history | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-030 | ownership_conflict | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-031 | needs_more_info | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-032 | vendor | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-033 | collaborative | COLLABORATIVE_INVESTIGATION | COLLABORATIVE_INVESTIGATION | high | PASS |
| SCN-034 | access_control_safety | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-035 | high_confidence | RETAIN_WITH_WEALTH | RETAIN_WITH_WEALTH | high | PASS |
| SCN-036 | must_abstain | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-037 | shared_error_text | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | high | PASS |
| SCN-038 | different_root_causes | MANUAL_REVIEW | MANUAL_REVIEW | low | PASS |
| SCN-039 | risky_kb_action | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | medium | PASS |
| SCN-040 | reopened_history | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | medium | PASS |
| SCN-041 | ambiguous_ownership_matrix | REASSIGN_TO_ANOTHER_TEAM | REASSIGN_TO_ANOTHER_TEAM | low | PASS |
| SCN-042 | collaborative | COLLABORATIVE_INVESTIGATION | COLLABORATIVE_INVESTIGATION | high | PASS |


## Notes

All labels are stripped from the payload before analysis (evaluation is adversarial to the engine).:

- Required evidence types per scenario are checked as a subset of the actual evidence.
- Safety flags are checked against the required behaviour.
- Confidence behaviour labels: high | medium | medium_max | abstain | any.
- 'medium_max' accepts low or medium; 'medium' requires exactly medium.