"""Mock SharePoint knowledge-base integration for the POC demo.

Real connector documentation is kept in the README; the mock simulates the
SharePoint-hosted knowledge-base site used by the demo:
  * search articles by free text, error code or application
  * fetch a single article
  * report site sync status (simulated poll)

All data is SYNTHETIC DEMO DATA.
"""
from __future__ import annotations

import sqlite3

from services import knowledge as knowledge_service, loader as loader_mod

SIMULATED_SITE = "https://demo.wm-demo.sharepoint.com/sites/knowledge"


def connect(db_path: str | None = None) -> sqlite3.Connection:
    return loader_mod.connect(db_path)


def search(query: str, top_n: int = 5, db_path: str | None = None) -> list[dict]:
    """Search the knowledge base (mock of the SharePoint KB search endpoint)."""
    conn = connect(db_path)
    try:
        knowledge = loader_mod.knowledge_frame(conn)
        retriever = knowledge_service.KnowledgeRetriever(knowledge)
        results = retriever.search({"error_message": query, "short_description": query}, top_k=top_n)
        return results["approved"] + results["warnings"]
    finally:
        conn.close()


def get_article(article_id: str, db_path: str | None = None) -> dict | None:
    conn = connect(db_path)
    try:
        knowledge = loader_mod.knowledge_frame(conn)
        return knowledge_service.KnowledgeRetriever(knowledge).get(article_id)
    finally:
        conn.close()


def sync_status(db_path: str | None = None) -> dict:
    """Report the simulated SharePoint site status (polling the demo site)."""
    return {
        "site": SIMULATED_SITE,
        "status": "connected",
        "last_sync": "2026-10-24T09:12:00Z",
        "article_count": 49,
        "approval_status": {
            "approved": 42,
            "outdated": 4,
            "draft": 3,
        },
    }
