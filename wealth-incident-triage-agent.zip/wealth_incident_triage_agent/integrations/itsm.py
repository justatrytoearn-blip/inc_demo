"""Mock ITSM integration for the POC demo.

Real connector documentation is kept in the README; the mock stores data in
the same SQLite state database and mirrors the shape of the demo API:
  * list / get / create / update tickets
  * apply an operator decision (accept, reject, manual_review, edit_destination)
  * send a ticket update that is stored as the simulated action

All data is SYNTHETIC DEMO DATA.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

import config
from services import audit as audit_mod, loader as loader_mod

STATUS_ESCALATED = ("escalated", "manual_review", "duplicate")


def connect(db_path: str | None = None) -> sqlite3.Connection:
    return loader_mod.connect(db_path)


def list_tickets(status: str | None = None, db_path: str | None = None) -> list[dict]:
    conn = connect(db_path)
    try:
        return loader_mod.list_incoming(conn, status)
    finally:
        conn.close()


def get_ticket(incident_id: str, db_path: str | None = None) -> dict | None:
    conn = connect(db_path)
    try:
        return loader_mod.get_incoming(incident_id, conn)
    finally:
        conn.close()


def create_ticket(record: dict, db_path: str | None = None) -> dict:
    conn = connect(db_path)
    try:
        loader_mod.upsert_incoming(record, conn)
        return get_ticket(record["incident_id"], db_path)
    finally:
        conn.close()


def apply_decision(incident_id: str, decision: str, team: str = "",
                   note: str = "", db_path: str | None = None) -> dict | None:
    """Record an operator decision on an open ticket.

    decision in: accept | reject | manual_review | edit_destination
    Simulated side effects mirror a real ITSM workflow.
    """
    conn = connect(db_path)
    try:
        ticket = loader_mod.get_incoming(incident_id, conn)
        if not ticket:
            return None
        mapping = {
            "accept": "accepted",
            "reject": "rejected",
            "manual_review": "in_progress",
            "edit_destination": "reassigned",
        }
        new_status = mapping.get(decision, ticket.get("status", "new"))
        if decision == "edit_destination" and team:
            ticket["current_assignment_group"] = team
        ticket["status"] = new_status
        ticket["updated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        loader_mod.upsert_incoming(ticket, conn)

        audit_service(conn, incident_id, decision, team, note)
        return get_ticket(incident_id, db_path)
    finally:
        conn.close()


def audit_service(conn: sqlite3.Connection, incident_id: str, decision: str,
                  team: str, note: str) -> None:
    from services import audit as audit_mod
    final_action = ""
    if decision == "accept":
        final_action = f"Accepted by operator - assigned to {team or 'the proposed team'}."
    elif decision == "reject":
        final_action = "Rejected by operator - ticket closed without routing."
    elif decision == "manual_review":
        final_action = "Escalated to manual review."
    elif decision == "edit_destination":
        final_action = f"Reworked and reassigned to {team or 'team'}."
    if note:
        final_action += f" Note: {note}."
    audit_mod.log_event(
        conn, "decision", incident_id=incident_id,
        actor="operator", method=decision,
        final_action=final_action,
        notes=note,
    )


def ticket_update(incident_id: str, text: str, db_path: str | None = None) -> dict | None:
    """Simulate adding a comment to the ticket (stored on the demo record)."""
    conn = connect(db_path)
    try:
        ticket = loader_mod.get_incoming(incident_id, conn)
        if not ticket:
            return None
        ticket["updated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        loader_mod.upsert_incoming(ticket, conn)
        return get_ticket(incident_id, db_path)
    finally:
        conn.close()
