"""Integration adapter package (mock by default, real connectors documented)."""
