"""Flask web application for the Wealth Incident Triage Agent POC.

Pages:
  /            Dashboard (queue, metrics, recent audit trail)
  /queue       Open incident queue with statuses
  /knowledge   Knowledge base search (SharePoint simulated)
  /ownership   Ownership matrix
  /analyze     Demo selector + analyse a single incident
  /decision    Record an operator decision (accept/reject/manual review)
  /audit       Audit log
  /evaluation  Run the POC evaluation and view the report
  /templates   Template & import
  /analysis-config  Operator page to change the analysis type and prompt at runtime
  /kb-docs     KB / SOP upload
  /kb-docs/<doc_id>/steps  SOP steps for a KB doc
  /api/*       JSON API used by the pages
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from flask import (Flask, jsonify, redirect, render_template, request,
                   send_file, url_for)

import config
from integrations import itsm, sharepoint
from services import (audit as audit_mod, llm_adapter, loader as loader_mod,
                      metrics as metrics_mod, triage as triage_mod)

BASE_DIR = Path(__file__).resolve().parent

app = Flask(__name__,
            template_folder=str(config.TEMPLATES_DIR),
            static_folder=str(config.STATIC_DIR))
app.config["SECRET_KEY"] = config.SECRET_KEY
app.config["JSON_AS_ASCII"] = False

DB_PATH = config.DATABASE_PATH

Path(config.REPORTS_DIR).mkdir(parents=True, exist_ok=True)

_loader_counts = None


# ---------------------------------------------------------------------------
# bootstrap / helpers
# ---------------------------------------------------------------------------
def _ensure_loaded() -> dict:
    """Idempotent bootstrap: make sure the demo DB and datasets are present."""
    global _loader_counts
    if _loader_counts is None:
        _loader_counts = loader_mod.ensure_ready(DB_PATH)
    return _loader_counts


@app.before_request
def _bootstrap() -> None:
    _ensure_loaded()


def _metrics() -> dict:
    try:
        return metrics_mod.aggregate(triage_mod.list_results(500, DB_PATH))
    except Exception:  # noqa: BLE001
        return {}


def _hydrate_result(row: dict) -> dict:
    """Turn a stored triage_results row into the shape the templates expect."""
    result = dict(row)
    try:
        payload = json.loads(result.get("analysis_json") or "{}")
    except (TypeError, ValueError):
        payload = {}
    narrative = payload.get("narrative") or {}
    if isinstance(narrative, dict) and narrative.get("sections"):
        result["troubleshooting"] = narrative["sections"]
    else:
        result["troubleshooting"] = {}
        for line in str(result.get("troubleshooting") or "").split("\n\n"):
            if line.startswith("[") and "] " in line:
                key, _, text = line[1:].partition("] ")
                result["troubleshooting"][key.strip()] = text
    try:
        result["evidence"] = json.loads(result.get("evidence") or "[]")
    except (TypeError, ValueError):
        result["evidence"] = []
    if not isinstance(result.get("evidence"), list):
        result["evidence"] = []
    result["summary"] = result.get("summary") or payload.get("summary", "")
    result.setdefault("routing", result.get("recommendation", ""))
    result.setdefault("confidence", payload.get("confidence", 0))
    result.setdefault("caps", payload.get("caps", []))
    result.setdefault("flags", payload.get("flags", []))
    result.setdefault("missing", payload.get("missing", []))
    result.setdefault("duplicate_of", payload.get("duplicate_of", ""))
    return result


# ---------------------------------------------------------------------------
# pages
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    metrics = _metrics()
    return render_template(
        "index.html",
        metrics=metrics,
        recent=triage_mod.list_results(8, DB_PATH),
        queue=triage_mod.list_incoming("new", DB_PATH),
        loader=_ensure_loaded(),
        llm_available=llm_adapter.LLM_AVAILABLE,
    )


@app.route("/queue")
def queue_page():
    return render_template("queue.html",
                           tickets=triage_mod.list_incoming(None, DB_PATH))


@app.route("/knowledge")
def knowledge_page():
    query = request.args.get("q", "").strip()
    results = sharepoint.search(query, 8, DB_PATH) if query else []
    return render_template("knowledge.html", query=query, results=results,
                           sync=sharepoint.sync_status(DB_PATH))


@app.route("/ownership")
def ownership_page():
    conn = loader_mod.connect(DB_PATH)
    try:
        ownership = loader_mod.ownership_frame(conn)
    finally:
        conn.close()
    return render_template("ownership.html", ownership=ownership)


@app.route("/audit")
def audit_page():
    conn = loader_mod.connect(DB_PATH)
    try:
        events = audit_mod.recent(conn, 100)
    finally:
        conn.close()
    return render_template("audit.html", events=events)


@app.route("/evaluation")
def evaluation_page():
    run = request.args.get("run", "0") == "1"
    result = None
    if run:
        from scripts import run_evaluation
        result = run_evaluation.run_evaluation()
        try:
            run_evaluation.write_report(result)
        except Exception:  # noqa: BLE001
            pass
    return render_template("evaluation.html", result=result)


@app.route("/analysis-config")
def analysis_config_page():
    """Operator page to change the analysis type and prompt at runtime."""
    conn = loader_mod.connect(DB_PATH)
    try:
        keys = ("al_analysis_type", "al_system_prompt", "al_user_prompt", "al_template_file")
        rows = conn.execute(
            "SELECT config_key, config_value FROM demo_config WHERE config_key IN (?, ?, ?, ?)",
            keys,
        ).fetchall()
    finally:
        conn.close()
    cfg = {r["config_key"]: (r["config_value"] or "") for r in rows}
    return render_template(
        "analysis_config.html",
        al_type=cfg.get("al_analysis_type") or config.AL_ANALYSIS_TYPE or "standard",
        al_system_prompt=cfg.get("al_system_prompt", ""),
        al_user_prompt=cfg.get("al_user_prompt", ""),
        al_template_file=cfg.get("al_template_file", ""),
    )


@app.route("/template-status")
def template_status():
    conn = loader_mod.connect(DB_PATH)
    try:
        uploads = loader_mod.template_uploads(conn)
        kb = loader_mod.kb_doc_list(conn)
    finally:
        conn.close()
    return render_template("template_status.html", uploads=uploads, kb_docs=kb)


@app.route("/approval-queue")
def approval_queue_page():
    conn = loader_mod.connect(DB_PATH)
    try:
        rows = loader_mod.list_triage_results(conn, 200)
        incoming = {r["incident_id"]: dict(r) for r in loader_mod.list_incoming(conn)}
    finally:
        conn.close()
    tickets = []
    for row in rows:
        ticket = _hydrate_result(row)
        source = incoming.get(ticket["incident_id"], {})
        ticket["application_name"] = source.get("application_name", "")
        ticket["error_code"] = source.get("error_code", "")
        ticket["troubleshooting_steps"] = (
            ticket.get("troubleshooting_steps")
            or json.loads(row.get("analysis_json") or "{}").get("troubleshooting_steps", "")
            or "")
        tickets.append(ticket)
    return render_template("approval_queue.html", tickets=tickets)


@app.route("/templates")
def templates_page():
    inc = pd.read_csv(config.DATA_DIR / "template_historical_incidents.csv", dtype=str).fillna("")
    own = pd.read_csv(config.DATA_DIR / "template_ownership.csv", dtype=str).fillna("")
    conn = loader_mod.connect(DB_PATH)
    try:
        uploads = loader_mod.template_uploads(conn)
        kb_docs = loader_mod.kb_doc_list(conn)
    finally:
        conn.close()
    return render_template(
        "templates.html",
        incidents=list(inc.head(20).T.to_dict().values()),
        ownership=list(own.head(20).T.to_dict().values()),
        uploads=uploads, kb_docs=kb_docs,
        downloads={
            "incident": url_for("template_download", kind="incident"),
            "ownership": url_for("template_download", kind="ownership"),
        },
    )


@app.route("/templates/download/<kind>")
def template_download(kind: str):
    files = {
        "incident": config.DATA_DIR / "template_historical_incidents.csv",
        "ownership": config.DATA_DIR / "template_ownership.csv",
    }
    path = files.get(kind)
    if path is None or not path.exists():
        return jsonify({"ok": False, "error": "Template not found"}), 404
    return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/template-import", methods=["POST"])
def template_import():
    upload_type = request.form.get("upload_type", "")
    if upload_type not in ("incident", "ownership"):
        return jsonify({"ok": False, "error": "unknown upload type"}), 400
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"ok": False, "error": "No file selected"}), 400
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"ok": False, "error": "Only CSV files are accepted"}), 400
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = config.DATA_DIR / ("upload_" + uuid.uuid4().hex[:8] + "_" + f.filename)
    f.save(tmp)
    conn = loader_mod.connect(DB_PATH)
    try:
        try:
            result = loader_mod.template_upload_csv(conn, upload_type, tmp)
            status = "processed"
        except Exception as exc:  # noqa: BLE001
            status = "rejected"
            result = loader_mod.save_template_upload(conn, {
                "upload_type": upload_type, "file_name": f.filename,
                "file_size_bytes": tmp.stat().st_size, "mime_type": f.mimetype or "",
                "parsed_rows": 0, "errors": json.dumps([str(exc)]), "status": status,
            })
    finally:
        conn.close()
    return jsonify({"ok": True, "upload_type": upload_type, "status": status, "upload": result})


# ---------------------------------------------------------------------------
# KB / SOP documents
# ---------------------------------------------------------------------------
@app.route("/kb-docs", methods=["GET", "POST"])
def kb_docs_page():
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            return jsonify({"ok": False, "error": "No file selected"}), 400
        if not (f.mimetype.startswith("text/") or f.mimetype.startswith("application/")):
            return jsonify({"ok": False, "error": "Only text-based files are accepted"}), 400
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix="." + f.filename.rsplit(".", 1)[-1])
        tmp.write(f.read())
        tmp.close()
        raw_path = config.DATA_DIR / f.filename
        shutil.move(tmp.name, raw_path)
        content = loader_mod._read_text(raw_path)
        doc_id = str(uuid.uuid4())
        team = request.form.get("team", "Wealth Application Support").strip()
        title = request.form.get("title", f.name.rsplit(".", 1)[0])
        approved = 1 if request.form.get("approved") else 0
        conn = loader_mod.connect(DB_PATH)
        try:
            loader_mod.save_kb_doc(conn, doc_id, f.filename, f.mimetype or "text/plain",
                                   raw_path.stat().st_size, title, team, content,
                                   str(raw_path), approved)
            if content:
                loader_mod.save_sop_step(
                    conn, doc_id, 0, "First-level quick start",
                    title, content[:2000], "pending")
        finally:
            conn.close()
        return jsonify({"ok": True, "doc_id": doc_id})

    conn = loader_mod.connect(DB_PATH)
    try:
        docs = loader_mod.kb_doc_list(conn)
        teams = loader_mod.get_teams(conn)
    finally:
        conn.close()
    return render_template("kb_sop_upload.html", docs=docs, teams=teams)


@app.route("/kb-docs/<doc_id>/steps")
def kb_doc_steps(doc_id):
    conn = loader_mod.connect(DB_PATH)
    try:
        steps = loader_mod.sop_steps_list(conn, doc_id)
        doc = next((d for d in loader_mod.kb_doc_list(conn) if d["doc_id"] == doc_id), None)
    finally:
        conn.close()
    if doc is None:
        return render_template("kb_sop_steps.html", doc={}, steps=[]), 404
    return render_template("kb_sop_steps.html", doc=doc, steps=steps)


@app.route("/api/sop-steps/use", methods=["POST"])
def api_sop_step_use():
    data = request.get_json(silent=True) or {}
    step_id = str(data.get("step_id", "")).strip()
    if not step_id:
        return jsonify({"ok": False, "error": "step_id required"}), 400
    conn = loader_mod.connect(DB_PATH)
    try:
        conn.execute("UPDATE sop_steps SET status = 'used' WHERE step_id = ?", (step_id,))
        conn.commit()
    finally:
        conn.close()
    return jsonify({"ok": True, "step_id": step_id})


# ---------------------------------------------------------------------------
# New incident / analysis
# ---------------------------------------------------------------------------
@app.route("/new-incident")
def new_incident_page():
    conn = loader_mod.connect(DB_PATH)
    try:
        teams = loader_mod.get_teams(conn)
        queue = loader_mod.list_incoming(conn, "new")
    finally:
        conn.close()
    return render_template(
        "new_incident_form.html",
        teams=teams,
        recent=triage_mod.list_results(5, DB_PATH),
        queue=queue,
        incident_id=request.args.get("incident", ""),
    )


@app.route("/api/new-incident", methods=["POST"])
def api_new_incident():
    data = request.get_json(force=True, silent=True) or {}
    inc_id = data.get("incident_id") or f"INC-{uuid.uuid4().hex[:8].upper()}"
    record = {
        "incident_id": inc_id,
        "created_at": data.get("created_at") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "short_description": data.get("short_description", ""),
        "detailed_description": data.get("detailed_description", ""),
        "application_name": data.get("application_name", ""),
        "business_service": data.get("business_service", ""),
        "environment": data.get("environment", "production"),
        "error_code": data.get("error_code", ""),
        "error_message": data.get("error_message", ""),
        "severity": data.get("severity", "3 - Moderate"),
        "priority": data.get("priority", "P3"),
        "business_impact": data.get("business_impact", ""),
        "affected_users": int(data.get("affected_users") or 0),
        "current_assignment_group": data.get("current_assignment_group") or "Wealth Application Support",
        "requester_role": data.get("requester_role", ""),
        "source": "template",
        "status": "new",
        "demo_tag": "free-text entry",
    }
    conn = loader_mod.connect(DB_PATH)
    try:
        loader_mod.upsert_incoming(record, conn)
        open_tickets = loader_mod.list_incoming(conn, "new")
    finally:
        conn.close()
    result = triage_mod.analyze(
        record, db_path=DB_PATH, open_tickets=open_tickets,
        data={
            "analysis_note": data.get("analysis_note", ""),
            "first_level_owner": data.get("first_level_owner", ""),
            "first_level_owner_contact": data.get("first_level_owner_contact", ""),
            "first_level_owner_note": data.get("first_level_owner_note", ""),
            "troubleshooting_steps": data.get("troubleshooting_steps", ""),
        },
    )
    return jsonify({"ok": True, "result": result})


@app.route("/analyze", methods=["GET", "POST"])
def analyze_page():
    demo_incidents = triage_mod.list_incoming("new", DB_PATH)
    incident = None
    result = None
    error = None
    inc_id = (request.form.get("incident_id") or request.args.get("incident") or "").strip()
    if inc_id:
        incident = triage_mod.get_incoming(inc_id, DB_PATH)
        if not incident:
            error = "Incident not found."
        else:
            try:
                result = triage_mod.analyze(incident, db_path=DB_PATH, persist=False)
            except Exception as exc:  # noqa: BLE001
                error = f"Analysis failed: {exc}"
    return render_template("analyze.html", incident=incident, result=result,
                           error=error, incidents=demo_incidents)


def _record_decision(inc_id: str, decision: str, team: str, note: str) -> dict | None:
    return itsm.apply_decision(inc_id, decision, team, note, DB_PATH)


@app.route("/decision", methods=["POST"])
def decision():
    payload = request.get_json(silent=True) or request.form.to_dict(flat=True)
    inc_id = str(payload.get("incident_id", "")).strip()
    choice = str(payload.get("decision", "accept")).strip() or "accept"
    team = str(payload.get("team", "")).strip()
    note = str(payload.get("note", "")).strip()
    ticket = _record_decision(inc_id, choice, team, note)
    if ticket is None:
        if request.is_json:
            return jsonify({"ok": False, "error": "Ticket not found"}), 404
        return redirect(url_for("queue_page"))
    if request.is_json:
        return jsonify({"ok": True, "ticket": ticket})
    return redirect(url_for("analyze_page", incident=inc_id))


@app.route("/api/decision", methods=["POST"])
def api_decision():
    payload = request.get_json(silent=True) or {}
    inc_id = str(payload.get("incident_id", "")).strip()
    choice = str(payload.get("decision", "accept")).strip() or "accept"
    ticket = _record_decision(inc_id, choice, str(payload.get("team", "")).strip(),
                              str(payload.get("note", "")).strip())
    if ticket is None:
        return jsonify({"ok": False, "error": "Ticket not found"}), 404
    return jsonify({"ok": True, "ticket": ticket})


@app.route("/api/incidents")
def api_incidents():
    status = request.args.get("status", "")
    tickets = triage_mod.list_incoming(status or None, DB_PATH)
    return jsonify([{k: v for k, v in t.items()} for t in tickets])


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    try:
        payload = request.get_json(force=True, silent=True) or {}
        incident = triage_mod.get_incoming(payload.get("incident_id", ""), DB_PATH)
        if not incident:
            return jsonify({"error": "incident not found"}), 404
        result = triage_mod.analyze(
            incident, db_path=DB_PATH,
            data={
                "analysis_note": payload.get("analysis_note", ""),
                "first_level_owner": payload.get("first_level_owner", ""),
                "first_level_owner_contact": payload.get("first_level_owner_contact", ""),
                "first_level_owner_note": payload.get("first_level_owner_note", ""),
                "troubleshooting_steps": payload.get("troubleshooting_steps", ""),
            },
        )
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 500


@app.route("/api/results")
def api_results():
    results = triage_mod.list_results(200, DB_PATH)
    return jsonify([{k: v for k, v in r.items() if k != "analysis_json"} for r in results])


# ---------------------------------------------------------------------------
# AL (analysis language) configuration API
# ---------------------------------------------------------------------------
@app.route("/api/al-config", methods=["GET", "POST"])
def api_al_config():
    """Read or update the runtime AL analysis type / prompt configuration.

    POST body: {"key": "analysis_type|system_prompt|user_prompt|template_file",
                "value": "<new value>"}
    POST body key=reset -> wipe the custom values and restore built-in defaults.
    """
    conn = loader_mod.connect(DB_PATH)
    try:
        if request.method == "GET":
            keys = ("al_analysis_type", "al_system_prompt", "al_user_prompt", "al_template_file")
            rows = conn.execute(
                "SELECT config_key, config_value FROM demo_config WHERE config_key IN (?, ?, ?, ?)",
                keys,
            ).fetchall()
            cfg = {r["config_key"]: (r["config_value"] or "") for r in rows}
            return jsonify({
                "analysis_type": cfg.get("al_analysis_type") or config.AL_ANALYSIS_TYPE or "standard",
                "system_prompt": cfg.get("al_system_prompt", ""),
                "user_prompt": cfg.get("al_user_prompt", ""),
                "template_file": cfg.get("al_template_file", ""),
            })

        data = request.get_json(force=True, silent=True) or {}
        key = str(data.get("key", "")).strip()
        value = str(data.get("value", ""))
        if key == "reset":
            conn.execute(
                "DELETE FROM demo_config WHERE config_key IN (?, ?, ?, ?)",
                ("al_analysis_type", "al_system_prompt", "al_user_prompt", "al_template_file"),
            )
            conn.commit()
            return jsonify({"ok": True, "message": "AL config reset to defaults"})
        if key not in ("analysis_type", "system_prompt", "user_prompt", "template_file"):
            return jsonify({"ok": False, "error": "unknown config key"}), 400
        conn.execute(
            "INSERT OR REPLACE INTO demo_config (config_key, config_value) VALUES (?, ?)",
            (f"al_{key}", value),
        )
        conn.commit()
        return jsonify({"ok": True, "message": f"AL {key} saved"})
    finally:
        conn.close()


if __name__ == "__main__":
    port = int(os.environ.get("TRIAGE_PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=True)
