"""Audit logging for the POC state database.

Every analysis, human decision and action on an incident is written to the
audit_log table so the demo has an explainable, replayable trail.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

import config


def log_event(conn: sqlite3.Connection, event_type: str, incident_id: str = "",
              actor: str = "system", method: str = "", evidence_refs: list[str] | None = None,
              recommendation: str = "", confidence: str = "", human_decision: str = "",
              final_action: str = "", notes: str = "") -> None:
    """Append one row to the audit log."""
    conn.execute(
        """INSERT INTO audit_log
           (event_time, event_type, incident_id, actor, method, evidence_refs,
            recommendation, confidence, human_decision, final_action, notes)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
         event_type, incident_id, actor, method,
         "[" + ",".join(evidence_refs or []) + "]",
         recommendation, confidence, human_decision, final_action, notes),
    )
    conn.commit()


def recent(conn: sqlite3.Connection, limit: int = 100) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM audit_log ORDER BY event_time DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]
