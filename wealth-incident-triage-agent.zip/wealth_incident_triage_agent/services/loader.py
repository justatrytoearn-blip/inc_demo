"""Dataset loading, validation and SQLite persistence for the POC.

Responsibilities:
  * initialise the SQLite demo-state database from database/schema.sql
  * guard CSV imports (size limits, required columns, row limits)
  * load the synthetic CSV datasets into SQLite (reference + incidents)
  * expose pandas DataFrames used by the matcher / retriever
  * provide simple CRUD for incoming incidents and triage results

All datasets are SYNTHETIC DEMO DATA.
"""
from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd

import config

# CSV source per SQLite table (test scenarios are read directly by the evaluator).
CSV_SOURCES: dict[str, Path] = {
    "team_ownership": config.OWNERSHIP_CSV,
    "knowledge_articles": config.KNOWLEDGE_CSV,
    "historical_incidents": config.HISTORICAL_CSV,
    "incoming_incidents": config.INCOMING_CSV,
}

REQUIRED_COLUMNS: dict[str, set[str]] = {
    "team_ownership": {"team_name"},
    "knowledge_articles": {"article_id", "title"},
    "historical_incidents": {"incident_id", "created_at", "short_description"},
    "incoming_incidents": {"incident_id", "created_at", "short_description"},
    "template_uploads": {"upload_id"},
    "kb_docs": {"doc_id"},
    "sop_steps": {"step_id"},
}



# ---------------------------------------------------------------------------
# Connection / schema
# ---------------------------------------------------------------------------
def connect(db_path: Path | str | None = None) -> sqlite3.Connection:
    """Open a new SQLite connection (one per call - safe for the threaded dev server)."""
    path = Path(db_path) if db_path else Path(config.DATABASE_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_database(conn: sqlite3.Connection, schema_path: Path | None = None) -> None:
    """Apply database/schema.sql (idempotent: CREATE ... IF NOT EXISTS)."""
    path = Path(schema_path) if schema_path else Path(config.SCHEMA_PATH)
    if not path.exists():
        raise ValueError(f"Schema file not found: {path}")
    conn.executescript(path.read_text(encoding="utf-8"))
    conn.commit()


# ---------------------------------------------------------------------------
# CSV import guards
# ---------------------------------------------------------------------------
def read_csv_guarded(
    path: Path | str,
    required_columns: Iterable[str] = (),
    *,
    max_rows: int | None = None,
    max_bytes: int | None = None,
) -> pd.DataFrame:
    """Read a CSV with the POC import guard rails.

    Raises ValueError when the file is missing, oversized, over the row limit,
    unparsable, or missing columns the pipeline depends on.
    """
    path = Path(path)
    if not path.exists():
        raise ValueError(f"Dataset not found: {path}")
    max_bytes = config.MAX_CSV_BYTES if max_bytes is None else max_bytes
    max_rows = config.MAX_CSV_ROWS if max_rows is None else max_rows

    size = path.stat().st_size
    if size > max_bytes:
        raise ValueError(
            f"CSV {path.name} is {size} bytes which exceeds the limit of {max_bytes} bytes"
        )
    try:
        df = pd.read_csv(path)
    except Exception as exc:  # noqa: BLE001 - surfaced as a guarded import error
        raise ValueError(f"CSV {path.name} could not be parsed: {exc}") from exc

    missing = set(required_columns) - set(df.columns)
    if missing:
        raise ValueError(
            f"CSV {path.name} is missing required columns: {', '.join(sorted(missing))}"
        )
    if len(df) > max_rows:
        raise ValueError(
            f"CSV {path.name} has {len(df)} rows which exceeds the limit of {max_rows}"
        )
    return df.fillna("")


def load_datasets(conn: sqlite3.Connection) -> dict[str, int]:
    """Load every CSV source into SQLite. Returns a {table: row_count} summary."""
    init_database(conn)
    counts: dict[str, int] = {}
    for table, path in CSV_SOURCES.items():
        df = read_csv_guarded(
            path,
            REQUIRED_COLUMNS[table],
            max_rows=config.MAX_CSV_ROWS,
            max_bytes=config.MAX_CSV_BYTES,
        )
        conn.execute(f"DELETE FROM {table}")  # table names are fixed constants above
        df.to_sql(table, conn, if_exists="append", index=False)
        counts[table] = len(df)
    conn.commit()
    return counts


def ensure_ready(db_path: Path | str | None = None, force: bool = False) -> dict[str, int]:
    """Idempotent bootstrap: create schema and load datasets when missing (or forced)."""
    path = Path(db_path) if db_path else Path(config.DATABASE_PATH)
    needs_load = force or not path.exists()
    conn = connect(path)
    try:
        if needs_load:
            return load_datasets(conn)
        counts = {}
        for table in CSV_SOURCES:
            row = conn.execute(f"SELECT COUNT(*) AS n FROM {table}").fetchone()
            counts[table] = int(row["n"])
        if any(v == 0 for v in counts.values()):
            return load_datasets(conn)
        init_database(conn)  # make sure indexes exist
        return counts
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data access helpers
# ---------------------------------------------------------------------------
RESERVED_TABLES = {
    "triage_results", "audit_log", "demo_config",
    "template_uploads", "kb_docs", "sop_steps",
}


def frame(table: str, conn: sqlite3.Connection) -> pd.DataFrame:
    if table not in CSV_SOURCES and table not in RESERVED_TABLES:
        raise ValueError(f"Unknown table: {table}")
    return pd.read_sql(f"SELECT * FROM {table}", conn)


# ---------------------------------------------------------------------------
# Template / import uploads (historical incidents + ownership matrix)
# ---------------------------------------------------------------------------

def template_upload_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    """Expose template_uploads as a DataFrame."""
    return frame("template_uploads", conn)


def template_uploads(conn: sqlite3.Connection) -> list[dict]:
    """List all template uploads."""
    return frame("template_uploads", conn).to_dict("records")


def save_template_upload(
    conn: sqlite3.Connection,
    record: dict,
) -> dict:
    """Persist one template upload record from a dict (see template_import in app.py)."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    conn.execute(
        """INSERT INTO template_uploads
           (upload_id, upload_type, file_name, file_size_bytes, mime_type,
            parsed_rows, errors, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (record.get("upload_id", str(uuid.uuid4())), record.get("upload_type", ""),
         record.get("file_name", ""), record.get("file_size_bytes", 0),
         record.get("mime_type", ""), record.get("parsed_rows", 0),
         record.get("errors", "[]"), record.get("status", "processed"), now),
    )
    conn.commit()
    return {
        "upload_id": record.get("upload_id", str(uuid.uuid4())),
        "upload_type": record.get("upload_type", ""),
        "file_name": record.get("file_name", ""),
        "file_size_bytes": record.get("file_size_bytes", 0),
        "mime_type": record.get("mime_type", ""),
        "parsed_rows": record.get("parsed_rows", 0),
        "errors": record.get("errors", "[]"),
        "status": record.get("status", "processed"),
        "created_at": now,
    }


# ---------------------------------------------------------------------------
# KB / SOP documentation uploads (PDF, DOCX, TXT, MD -> plain text + indexed steps)
# ---------------------------------------------------------------------------

def kb_docs_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("kb_docs", conn)


def kb_doc_list(conn: sqlite3.Connection) -> list[dict]:
    return frame("kb_docs", conn).to_dict("records")


def sop_steps_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("sop_steps", conn)


def sop_steps_list(conn: sqlite3.Connection, doc_id: str | None = None) -> list[dict]:
    steps = frame("sop_steps", conn)
    if doc_id:
        steps = steps[steps["doc_id"] == doc_id]
    if "position" in steps.columns:
        steps = steps.sort_values("position")
    return steps.to_dict("records")


def save_kb_doc(
    conn: sqlite3.Connection,
    doc_id: str,
    file_name: str,
    mime_type: str,
    byte_size: int,
    title: str,
    team: str,
    content: str,
    raw_path: str,
    approved: int,
) -> dict:
    """Persist one uploaded KB/SOP document."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    conn.execute(
        """INSERT INTO kb_docs
           (doc_id, file_name, mime_type, byte_size, title, team, content,
            raw_path, approved, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (doc_id, file_name, mime_type, byte_size, title, team, content,
         raw_path, approved, now, now),
    )
    conn.commit()
    return {
        "doc_id": doc_id,
        "file_name": file_name,
        "mime_type": mime_type,
        "byte_size": byte_size,
        "title": title,
        "team": team,
        "approved": bool(approved),
        "created_at": now,
        "updated_at": now,
    }


def save_sop_step(
    conn: sqlite3.Connection,
    doc_id: str,
    position: int,
    label: str,
    headline: str,
    body: str,
    status: str = "pending",
) -> dict:
    """Persist one parsed troubleshooting step of a KB/SOP document."""
    step_id = f"{doc_id}_step_{position:03d}"
    conn.execute(
        """INSERT OR REPLACE INTO sop_steps
           (step_id, doc_id, position, label, headline, body, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (step_id, doc_id, position, label, headline, body, status),
    )
    conn.commit()
    return {
        "step_id": step_id, "doc_id": doc_id, "position": position,
        "label": label, "headline": headline, "body": body, "status": status,
    }


# ---------------------------------------------------------------------------
# KB / SOP document parsing (PDF | DOCX | TXT | MD -> plain text + indexed steps)
# ---------------------------------------------------------------------------

def _read_text(path: Path) -> str:
    """Extract plain text from PDF, DOCX, TXT or MD. Returns '' when unsupported."""
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            import pdfplumber  # optional extra, graceful fallback
            with pdfplumber.open(path) as pdf:
                return "\n".join((page.extract_text() or "") for page in pdf.pages)
        if suffix == ".docx":
            from docx import Document
            return "\n".join(p.text for p in Document(path).paragraphs)
        if suffix in (".txt", ".md"):
            return path.read_text(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return ""
    return ""


def parse_kb_document(path: Path) -> dict:
    """Parse an uploaded KB/SOP document into a title + team + plain text.

    The caller (controller) is responsible for deciding whether a real
    out-of-the-box parser library will be installed or whether text-only
    extraction is enough for the first-level troubleshooting step.
    """
    content = _read_text(path)
    return {
        "file_name": path.name,
        "mime_type": path.suffix.lower(),
        "byte_size": path.stat().st_size if path.exists() else 0,
        "content": content,
    }


# ---------------------------------------------------------------------------
# First-level team + incident write (new incidents)
# ---------------------------------------------------------------------------

def get_teams(conn: sqlite3.Connection) -> list[str]:
    """Return the first-level owning teams available for a new incident."""
    rows = conn.execute(
        "SELECT DISTINCT team_name FROM team_ownership WHERE active_status = 'active' ORDER BY team_name"
    ).fetchall()
    return [r[0] for r in rows]


def get_ownership_entry(conn: sqlite3.Connection, team: str) -> dict | None:
    """Return the matrix row for a team (escalation conditions, restricted actions)."""
    rows = conn.execute(
        "SELECT * FROM team_ownership WHERE team_name = ?", (team,)
    ).fetchall()
    if not rows:
        return None
    r = rows[0]
    return {
        "team_name": r["team_name"],
        "escalation_conditions": r["escalation_conditions"],
        "restricted_actions": r["restricted_actions"],
        "business_hours_or_support_model": r["business_hours_or_support_model"],
    }


# ---------------------------------------------------------------------------
# Template uploads: historical incidents CSV + ownership matrix CSV
# ---------------------------------------------------------------------------

def template_upload_csv(conn: sqlite3.Connection, upload_type: str, path: Path) -> dict:
    """Parse and persist one template CSV uploaded by an operator.

    * type=incident    : the historic-incident template (see
                          data/template_historical_incidents.csv for the exact
                          header row), rows are loaded into historical_incidents
    * type=ownership   : the ownership-matrix template (see
                          data/template_ownership.csv), rows are loaded into
                          team_ownership
    """
    import pandas as pd

    req = {
        "incident": (
            "incident_id", "created_at", "short_description", "detailed_description",
            "application_name", "business_service", "environment", "error_code",
            "error_message", "severity", "priority", "business_impact",
            "affected_users", "initial_assignment_group", "final_resolver_team",
            "resolution_status", "previous_troubleshooting", "root_cause",
            "resolution_summary", "knowledge_article_id", "resolution_time_minutes",
            "historical_record_quality", "data_label",
        ),
        "ownership": ("team_name", "supported_services", "supported_applications",
                      "common_error_patterns", "ownership_description",
                      "escalation_conditions", "restricted_actions",
                      "business_hours_or_support_model", "active_status"),
    }[upload_type]

    template_file = {
        "incident": "template_historical_incidents.csv",
        "ownership": "template_ownership.csv",
    }[upload_type]
    data_path = Path(config.DATA_DIR) / template_file
    if not data_path.exists():
        raise ValueError(f"Template file not found: {data_path}")
    df = pd.read_csv(data_path, dtype=str).fillna("")
    if len(df) > config.MAX_CSV_ROWS:
        raise ValueError(f"Template has {len(df)} rows; max {config.MAX_CSV_ROWS} allowed.")

    # The historical-incident template is the same format the engine already
    # knows. ``first_level_owner`` is optional - it is only used as a default
    # when the operator does not override the team on the incident tab.
    missing = set(req) - set(df.columns)
    if missing:
        raise ValueError(f"Template missing required columns: {', '.join(sorted(missing))}")

    # Load the parsed template rows into the reference tables in the DB.
    if upload_type == "incident":
        df.to_sql("historical_incidents", conn, if_exists="append", index=False)
    else:
        df.to_sql("team_ownership", conn, if_exists="append", index=False)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    upload_id = str(uuid.uuid4())
    conn.execute(
        """INSERT INTO template_uploads
           (upload_id, upload_type, file_name, file_size_bytes, mime_type,
            parsed_rows, errors, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (upload_id, upload_type, path.name, path.stat().st_size,
         "text/csv", len(df), "[]", "processed", now),
    )
    conn.commit()
    return {
        "upload_id": upload_id,
        "upload_type": upload_type,
        "file_name": path.name,
        "parsed_rows": len(df),
        "status": "processed",
        "created_at": now,
    }


def ownership_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("team_ownership", conn)


def knowledge_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("knowledge_articles", conn)


def history_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("historical_incidents", conn)


def incoming_frame(conn: sqlite3.Connection) -> pd.DataFrame:
    return frame("incoming_incidents", conn)


def list_incoming(conn: sqlite3.Connection, status: str | None = None) -> list[dict]:
    if status:
        rows = conn.execute(
            "SELECT * FROM incoming_incidents WHERE status = ? ORDER BY created_at DESC",
            (status,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM incoming_incidents ORDER BY created_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]


def get_incoming(incident_id: str, conn: sqlite3.Connection) -> dict | None:
    row = conn.execute(
        "SELECT * FROM incoming_incidents WHERE incident_id = ?", (incident_id,)
    ).fetchone()
    return dict(row) if row else None


def upsert_incoming(record: dict, conn: sqlite3.Connection) -> None:
    """Insert or update one incoming incident (ITSM mock writes)."""
    cols = [r[1] for r in conn.execute("PRAGMA table_info(incoming_incidents)")]
    known = {c: record.get(c, "") for c in cols if c in record}
    if "incident_id" not in known:
        raise ValueError("incident_id is required")
    placeholders = ", ".join("?" for _ in known)
    conn.execute(
        f"INSERT OR REPLACE INTO incoming_incidents ({', '.join(known)}) VALUES ({placeholders})",
        tuple(known.values()),
    )
    conn.commit()


TRIAGE_RESULT_COLUMNS = (
    "incident_id", "analyzed_at", "recommendation", "proposed_team", "secondary_team",
    "team_confidence", "match_confidence", "kb_confidence", "band", "summary",
    "troubleshooting", "ticket_update", "handover", "evidence", "analysis_json",
    "analysis_latency_ms", "llm_provider", "status",
    "operator_decision", "operator_team", "operator_note", "simulated_action",
)


def save_triage_result(result: dict, conn: sqlite3.Connection, status: str = "pending_approval") -> None:
    """Persist one analysis into triage_results (INSERT OR REPLACE)."""
    values = {
        "incident_id": result["incident_id"],
        "analyzed_at": result.get("analyzed_at", ""),
        "recommendation": result.get("recommendation") or result.get("routing", ""),
        "proposed_team": result.get("proposed_team", ""),
        "secondary_team": result.get("secondary_team", ""),
        "team_confidence": float(result.get("team_confidence", 0)),
        "match_confidence": float(result.get("match_confidence", 0)),
        "kb_confidence": float(result.get("kb_confidence", 0)),
        "band": result.get("band", ""),
        "summary": result.get("summary", ""),
        "troubleshooting": result.get("troubleshooting_text", ""),
        "ticket_update": result.get("ticket_update", ""),
        "handover": result.get("handover", ""),
        "evidence": result.get("evidence_json") or json.dumps(result.get("evidence", []), default=str),
        "analysis_json": result.get("analysis_json", "{}"),
        "analysis_latency_ms": int(result.get("analysis_latency_ms", result.get("latency_ms", 0)) or 0),
        "llm_provider": result.get("llm_provider", "rule_based_fallback"),
        "status": status,
    }
    cols = ", ".join(values)
    placeholders = ", ".join("?" for _ in values)
    conn.execute(
        f"INSERT OR REPLACE INTO triage_results ({cols}) VALUES ({placeholders})",
        tuple(values.values()),
    )
    conn.commit()


def get_triage_result(incident_id: str, conn: sqlite3.Connection) -> dict | None:
    row = conn.execute(
        "SELECT * FROM triage_results WHERE incident_id = ?", (incident_id,)
    ).fetchone()
    return dict(row) if row else None


def list_triage_results(conn: sqlite3.Connection, limit: int = 200) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM triage_results ORDER BY analyzed_at DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]
