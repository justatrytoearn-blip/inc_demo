"""Metrics computed from analysis results for the POC dashboard and reports.

The engine is a decision-support prototype, so the numbers here are
transparent estimates, not validated SLAs:
  * baseline = config.BASELINE_MANUAL_MINUTES per incident (demo default 120)
  * assisted minutes = baseline * factor, where factor depends on the band
    (high/medium/low confidence manual review)
  * scenario savings multiply the total manual baseline by an adoption
    reduction assumption (conservative / expected / optimistic)
"""
from __future__ import annotations

import config
from services import recommendation as recommendation_service

FACTORS = {"high": 0.20, "medium": 0.375, "low": 0.75}
LABELS = {"high": "high", "medium": "medium", "low": "low"}


def assisted_minutes(result: dict, baseline: float | None = None) -> float:
    """Estimated minutes spent on one incident (research + decision + notes)."""
    baseline = baseline or config.BASELINE_MANUAL_MINUTES
    band = result.get("band", "low")
    return round(baseline * FACTORS.get(band, FACTORS["low"]), 1)


def aggregate(results: list[dict], baseline: float | None = None) -> dict:
    """Aggregate a list of triage results into a metrics payload."""
    baseline = baseline or config.BASELINE_MANUAL_MINUTES
    by_band: dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    by_routing: dict[str, int] = {}
    assisted_total = 0.0
    manual_total = 0.0
    for r in results:
        band = r.get("band", "low")
        by_band[band] = by_band.get(band, 0) + 1
        routing = r.get("routing") or r.get("recommendation") or ""
        by_routing[routing] = by_routing.get(routing, 0) + 1
        manual_total += baseline
        assisted_total += assisted_minutes(r, baseline)
    return {
        "baseline_minutes": baseline,
        "baseline_incidents": len(results),
        "by_band": by_band,
        "by_routing": by_routing,
        "assisted_minutes": round(assisted_total, 1),
        "saved_minutes": round(manual_total - assisted_total, 1),
        "saved_hours": round((manual_total - assisted_total) / 60, 2),
        "assist_rate": round(100.0 * assisted_total / max(manual_total, 1), 1),
        "abstain_count": sum(1 for r in results if r.get("abstain")),
    }


def scenario_savings(aggregate_result: dict, reduction: float, label: str = "") -> dict:
    """Alternative adoption scenarios: share of total manual effort avoided."""
    base = aggregate_result["baseline_minutes"]
    avoided = round(base * reduction, 1)
    return {
        "scenario": label or "default",
        "reduction_setting": reduction,
        "manual_baseline_minutes": base,
        "projected_minutes_saved": avoided,
        "projected_hours_saved": round(avoided / 60, 2),
    }
