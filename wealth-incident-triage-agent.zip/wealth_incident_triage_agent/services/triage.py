"""Triage orchestrator for the POC.

Assembles the context (ownership, history, KB), runs the routing decision,
produces the narrative, and persists results plus audit events. The engine
is a transparent heuristic - no model is trained or hosted here.
"""
from __future__ import annotations

import json
import time

import pandas as pd

from services import (audit as audit_service, llm_adapter, loader as loader_mod,
                      metrics as metrics_service, recommendation, knowledge as knowledge_service)
from services import matcher as matcher_service

# Thread-safe pipeline context. The DataFrame / matcher / retriever objects are
# read-only views over the demo data (SQLite is not shared), so they can be
# safely re-used. The SQLite connection itself is created fresh on every call
# because the Flask dev server serves each request on a new thread.


def _context(db_path: str | None = None):
    """Build the pipeline context for one database, opening a fresh connection."""
    conn = loader_mod.connect(db_path)
    try:
        ownership = loader_mod.ownership_frame(conn)
        history = loader_mod.history_frame(conn)
        knowledge = loader_mod.knowledge_frame(conn)
        matcher = matcher_service.HistoryMatcher(history)
        retriever = knowledge_service.KnowledgeRetriever(knowledge)
        return (conn, ownership, history, matcher, retriever, [])
    except Exception:  # noqa: BLE001
        conn.close()
        raise


def _fresh_incident(incident: dict) -> dict:
    """The payload the engine receives - no label columns, only free text."""
    return {
        "incident_id": incident.get("incident_id", ""),
        "created_at": incident.get("created_at", ""),
        "short_description": incident.get("short_description", ""),
        "detailed_description": incident.get("detailed_description", ""),
        "application_name": incident.get("application_name", ""),
        "business_service": incident.get("business_service", ""),
        "environment": incident.get("environment", "production"),
        "error_code": incident.get("error_code", ""),
        "error_message": incident.get("error_message", ""),
        "severity": incident.get("severity", "3 - Moderate"),
        "priority": incident.get("priority", "P3"),
        "business_impact": incident.get("business_impact", ""),
        "affected_users": incident.get("affected_users", 0),
        "current_assignment_group": incident.get("current_assignment_group", ""),
        "source": incident.get("source", "demo"),
        "status": incident.get("status", "new"),
        "demo_tag": incident.get("demo_tag", ""),
    }


def analyze(incident: dict, *, db_path: str | None = None,
            persist: bool = True, open_tickets: list[dict] | None = None,
            data: dict | None = None) -> dict:
    """Analyse one incident and return the full analysis result.

    ``data`` carries the operator-entered fields (analysis note, first-level
    owner, first-level owner contact/note and troubleshooting steps) that are
    persisted alongside the report so the approval/decline and notes UI can
    read them back without re-running the engine.
    """
    t0 = time.perf_counter()
    conn, ownership, history, matcher, retriever, _ = _context(db_path)
    inc = _fresh_incident(incident)
    try:
        inputs = recommendation.DecisionInputs(
            inc, ownership, history, matcher, retriever, open_tickets=open_tickets)
    finally:
        # The in-memory frames do not need the SQLite handle any more.
        conn.close()

    decision = recommendation.decide(inputs)

    # band (abstain forces low; caps apply inside _score)
    decision["band"] = recommendation.band_for(decision["confidence"], decision.get("abstain", False))
    decision["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)

    # narrative (LLM first, rule-based fallback)
    context = {"incident": inc, "decision": decision, "text": inputs.text,
               "codes": inputs.codes, "now": decision.get("analyzed_at", "")}
    narrative = llm_adapter.generate_narrative(context)
    decision["narrative"] = narrative["narrative"]
    decision["llm_provider"] = narrative["provider"]

    data = data or {}
    result = {
        "incident_id": inc["incident_id"],
        "analyzed_at": decision.get("analyzed_at", "") or "",
        "recommendation": decision["routing"],
        "proposed_team": decision["proposed_team"],
        "secondary_team": decision.get("secondary_team", ""),
        "team_confidence": decision.get("team_confidence", 0.0),
        "match_confidence": decision.get("match_confidence", 0.0),
        "kb_confidence": decision.get("kb_confidence", 0.0),
        "band": decision["band"],
        "confidence": decision["confidence"],
        "caps": decision.get("caps", []),
        "flags": decision.get("flags", []),
        "evidence": decision.get("evidence", []),
        "missing": decision.get("missing", []),
        "duplicate_of": decision.get("duplicate_of", ""),
        "summary": decision["narrative"].get("summary", ""),
        "troubleshooting": decision["narrative"]["sections"],
        "troubleshooting_text": "\n\n".join(
            f"[{k}] {v}" for k, v in decision["narrative"]["sections"].items()),
        "ticket_update": decision["narrative"]["ticket_update"],
        "handover": decision["narrative"]["handover"],
        "analysis_json": json.dumps(decision, default=str),
        "analysis_latency_ms": decision["latency_ms"],
        "llm_provider": decision["llm_provider"],
        "status": "pending_approval",
        "abstain": decision.get("abstain", False),
        "abstain_reason": decision.get("abstain_reason", ""),
        "collab_teams": decision.get("collab_teams", []),
    }

    # Persist the report with operator context (note, first-level owner,
    # troubleshooting steps) so the approval/decline and notes UI can read
    # them back without re-running the engine.
    report = dict(result)
    report["analysis_note"] = data.get("analysis_note", "")
    report["first_level_owner"] = data.get("first_level_owner", "")
    report["first_level_owner_contact"] = data.get("first_level_owner_contact", "")
    report["first_level_owner_note"] = data.get("first_level_owner_note", "")
    report["troubleshooting_steps"] = data.get("troubleshooting_steps", "")
    if persist:
        conn = loader_mod.connect(db_path)
        try:
            loader_mod.save_triage_result(report, conn)
            audit_service.log_event(
                conn, "analysis", incident_id=inc["incident_id"],
                evidence_refs=[e["type"] for e in result["evidence"]],
                recommendation=decision["routing"], confidence=str(decision["confidence"]),
                notes=" ".join(decision.get("flags") or []))
        finally:
            conn.close()
    return report


def list_incoming(status: str | None = None, db_path: str | None = None) -> list[dict]:
    conn = loader_mod.connect(db_path)
    try:
        return loader_mod.list_incoming(conn, status)
    finally:
        conn.close()


def get_incoming(incident_id: str, db_path: str | None = None) -> dict | None:
    conn = loader_mod.connect(db_path)
    try:
        return loader_mod.get_incoming(incident_id, conn)
    finally:
        conn.close()


def get_result(incident_id: str, db_path: str | None = None) -> dict | None:
    conn = loader_mod.connect(db_path)
    try:
        return loader_mod.get_triage_result(incident_id, conn)
    finally:
        conn.close()


def list_results(limit: int = 200, db_path: str | None = None) -> list[dict]:
    conn = loader_mod.connect(db_path)
    try:
        return loader_mod.list_triage_results(conn, limit)
    finally:
        conn.close()


def run_evaluation(scenarios_path: str | None = None) -> dict:
    """Evaluate all labeled scenarios through the engine and compare."""
    try:
        import pandas as pd
        from scripts import scenario_defs
        from services import metrics as metrics_service
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"evaluation setup failed: {exc}") from exc

    import config
    scenarios = [s.__dict__ for s in scenario_defs.SCENARIOS]
    open_tickets = loader_mod.list_incoming(None, config.DATABASE_PATH)

    results = []
    for s in scenarios:
        payload = _label_free_scenario(s)
        inc = dict(payload)
        inc["status"] = "new"
        res = analyze(inc, open_tickets=open_tickets, persist=False)
        results.append((s, res))

    checks = {
        "routing": 0, "confidence": 0, "evidence": 0, "troubleshooting": 0,
        "safety": 0, "total": len(scenarios),
    }
    rows = []
    for s, res in results:
        row = {"scenario_id": s["scenario_id"], "category": s["category"], "routing": s["routing"],
               "expected_routing": s["expected_routing"], "band": res["band"],
               "routing_ok": False, "confidence_ok": False, "evidence_ok": False,
               "safety_ok": False, "troubleshooting_ok": False, "passes": False,
               "missing": []}
        row["routing_ok"] = row["routing"] == row["expected_routing"]
        checks["routing"] += row["routing_ok"]

        expected_conf = s.get("expected_confidence_behavior", "any")
        row["confidence_ok"] = _confidence_ok(row["band"], expected_conf)
        checks["confidence"] += row["confidence_ok"]

        row["evidence_ok"] = _evidence_ok(s, res)
        checks["evidence"] += row["evidence_ok"]

        row["troubleshooting_ok"] = _troubleshooting_ok(res)
        checks["troubleshooting"] += row["troubleshooting_ok"]

        row["safety_ok"] = _safety_ok(s, res)
        checks["safety"] += row["safety_ok"]

        checks["total"] += 0
        row["passes"] = all([row["routing_ok"], row["confidence_ok"], row["evidence_ok"],
                             row["troubleshooting_ok"], row["safety_ok"]])
        rows.append(row)

    agg = metrics_service.aggregate([r for _, r in results])
    report = {
        "generated_at": __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "total_scenarios": checks["total"],
        "routing_accuracy": round(100.0 * checks["routing"] / max(checks["total"], 1), 1),
        "confidence_compliance": round(100.0 * checks["confidence"] / max(checks["total"], 1), 1),
        "evidence_compliance": round(100.0 * checks["evidence"] / max(checks["total"], 1), 1),
        "troubleshooting_compliance": round(100.0 * checks["troubleshooting"] / max(checks["total"], 1), 1),
        "safety_compliance": round(100.0 * checks["safety"] / max(checks["total"], 1), 1),
        "overall_pass_rate": round(100.0 * sum(r["passes"] for r in rows) / max(checks["total"], 1), 1),
        "per_scenario": rows,
        "metrics": agg,
    }
    return report


def _label_free_scenario(s: dict) -> dict:
    payload = {k: v for k, v in s.items()
               if k not in {"scenario_id", "category", "expected_routing",
                            "expected_team_set", "expected_confidence_behavior",
                            "required_safety_behavior", "expected_evidence",
                            "expected_troubleshooting", "evaluation_criteria"}}
    payload["current_assignment_group"] = "Wealth Application Support"
    return payload


def _confidence_ok(band: str, expected: str) -> bool:
    if expected == "any":
        return True
    if expected == "high":
        return band == "high"
    if expected == "medium":
        return band == "medium"
    if expected == "medium_max":
        return band in ("low", "medium")
    if expected == "abstain":
        return band == "low" and True
    return False


def _evidence_ok(s: dict, res: dict) -> bool:
    required = [te.replace("requires_", "") for te in s.get("expected_evidence", "").split("|")]
    actual = {e["type"] for e in res.get("evidence", [])}
    return all(req in actual for req in required)


def _troubleshooting_ok(res: dict) -> bool:
    sections = res.get("troubleshooting", {})
    return all(isinstance(sections.get(k), str) and len(sections[k]) > 20
               for k in ("A", "B", "C", "D", "E"))


def _safety_ok(s: dict, res: dict) -> bool:
    safety = s.get("required_safety_behavior", "none")
    flags = set(res.get("flags", []))
    if safety == "none":
        return True
    if safety == "warn_outdated_kb":
        return "outdated_kb_warning" in flags
    if safety == "reject_draft_kb":
        return "draft_kb_rejected" in flags
    if safety == "escalate_security":
        return "security_escalation" in flags and "no_account_action" in flags
    if safety == "no_bypass_access":
        return "access_control_refusal" in flags
    if safety == "no_destructive_action":
        return "destructive_action_requires_authorization" in flags
    return False
