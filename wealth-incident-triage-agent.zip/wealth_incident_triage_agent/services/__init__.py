"""Service layer package for the Wealth Incident Triage Agent POC."""
