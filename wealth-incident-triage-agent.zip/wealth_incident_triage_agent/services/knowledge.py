"""Knowledge base retrieval for the POC.

Rules enforced here:
  * only `approved` articles are used as guidance
  * `outdated` articles are returned as warnings only (never as guidance)
  * `draft` articles are rejected outright (not approved for use)
  * articles pointing at decommissioned teams are flagged outdated
  * destructive production actions in article steps are detected so the
    recommendation layer can demand explicit authorisation

All data is SYNTHETIC DEMO DATA.
"""
from __future__ import annotations

import re

import pandas as pd
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

import config

DECOMMISSIONED_RE = re.compile(r"decommissioned|legacy .* team", re.I)
DESTRUCTIVE_RE = re.compile(r"\b(restart|reboot|kill|delete|drop|disable|stop)\b", re.I)
AUTHORISATION_HINTS = ("approved", "change window", "change process", "within an approved")

KB_TEXT_FIELDS = (
    "title", "symptoms", "error_codes", "known_root_cause", "diagnostic_steps",
    "application_name", "category",
)


def _kb_text(row: pd.Series | dict) -> str:
    parts = [str(row.get(f, "") or "") for f in KB_TEXT_FIELDS]
    return " ".join(parts).lower()


def article_status(row: pd.Series | dict) -> str:
    """approved | outdated | draft - decommissioned escalation teams are outdated."""
    status = str(row.get("approval_status", "approved")).strip().lower()
    team = str(row.get("escalation_team", ""))
    if status == "approved" and DECOMMISSIONED_RE.search(team):
        return "outdated"
    return status if status in ("approved", "outdated", "draft") else "outdated"


def risky_action(row: pd.Series | dict) -> dict | None:
    """Detect a destructive production step that needs explicit authorisation."""
    if str(row.get("risk_level", "")).lower() != "high":
        return None
    steps = str(row.get("resolution_steps", "") or "")
    for step in [s.strip() for s in steps.split("|") if s.strip()]:
        low = step.lower()
        if not DESTRUCTIVE_RE.search(step):
            continue
        if low.startswith("do not"):
            continue  # prohibition, not an action
        if any(hint in low for hint in AUTHORISATION_HINTS):
            continue  # already bounded by an approval/change window
        return {"article_id": row.get("article_id", ""), "step": step}
    return None


class KnowledgeRetriever:
    """TF-IDF retrieval over the knowledge base with approval gating."""

    def __init__(self, knowledge: pd.DataFrame):
        self.kb = knowledge.copy().reset_index(drop=True)
        self._status = [article_status(r) for _, r in self.kb.iterrows()]
        if self.kb.empty:
            self._matrix = None
            return
        texts = [_kb_text(r) for _, r in self.kb.iterrows()]
        self._word = TfidfVectorizer(lowercase=True, ngram_range=(1, 2), sublinear_tf=True)
        self._char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5),
                                     lowercase=True, sublinear_tf=True)
        xw = self._word.fit_transform(texts)
        xc = self._char.fit_transform(texts)
        self._matrix = normalize(hstack([xw, xc]), norm="l2", axis=1)

    def search(self, incident: dict, top_k: int | None = None) -> dict:
        """Return {'approved': [...], 'warnings': [...]} for one incident."""
        top_k = top_k or config.TOP_KB_MATCHES
        empty = {"approved": [], "warnings": []}
        if self._matrix is None:
            return empty

        code = str(incident.get("error_code", "") or "").strip().lower()
        query = _kb_text(incident)
        vec = normalize(
            hstack([self._word.transform([query]), self._char.transform([query])]),
            norm="l2", axis=1,
        )
        scores = (self._matrix @ vec.T).toarray().ravel()

        candidates = []
        for idx in scores.argsort()[::-1][: top_k * 3]:
            row = self.kb.iloc[int(idx)]
            score = float(scores[idx])
            codes = [c.strip().lower() for c in str(row.get("error_codes", "")).split("|") if c.strip()]
            exact_code = bool(code) and code in codes
            if not exact_code and score < 0.35:
                continue
            candidates.append((row, score, exact_code))
        # exact error-code matches first, then by similarity
        candidates.sort(key=lambda c: (c[2], c[1]), reverse=True)

        approved: list[dict] = []
        warnings: list[dict] = []
        for row, score, exact_code in candidates:
            status = article_status(row)
            entry = {
                "article_id": row.get("article_id", ""),
                "title": row.get("title", ""),
                "application_name": row.get("application_name", ""),
                "score": round(0.95 if exact_code else score, 4),
                "status": status,
                "risk_level": row.get("risk_level", ""),
                "escalation_team": row.get("escalation_team", ""),
                "diagnostic_steps": row.get("diagnostic_steps", ""),
                "resolution_steps": row.get("resolution_steps", ""),
                "prerequisites": row.get("prerequisites", ""),
                "known_root_cause": row.get("known_root_cause", ""),
                "expected_results": row.get("expected_results", ""),
                "last_updated": row.get("last_updated", ""),
                "exact_code": exact_code,
                "risky_action": risky_action(row),
            }
            if status == "approved":
                if len(approved) < top_k:
                    approved.append(entry)
            else:
                if len(warnings) < top_k:
                    warnings.append(entry)
            if len(approved) >= top_k and len(warnings) >= top_k:
                break
        return {"approved": approved, "warnings": warnings}

    def get(self, article_id: str) -> dict | None:
        rows = self.kb[self.kb["article_id"] == article_id]
        if rows.empty:
            return None
        row = rows.iloc[0]
        entry = {k: row.get(k, "") for k in self.kb.columns}
        entry["status"] = article_status(row)
        entry["risky_action"] = risky_action(row)
        return entry
