"""Optional LLM narrative adapter for the POC.

The engine runs fully offline with rule-based narratives. When
TRIAGE_LLM_ENABLED=on and an API key is available, chat completions are
called against a compatible endpoint and the response is validated and
used in place of the rule-based draft. Any failure, malformed payload or
turn-taking attempt is ignored and the rule-based text is kept.
"""

from __future__ import annotations

import json
import os
import sqlite3
import urllib.error
import urllib.request

import config
from services import loader as loader_mod

LLM_AVAILABLE = bool(config.LLM_API_KEY)

DEFAULT_SYSTEM_PROMPT = (
    "You are a wealth-management incident triage assistant. "
    "You write a first-level troubleshooting narrative for a service desk analyst. "
    "Answer only with a JSON object using the keys: summary (string), "
    "sections (object with the keys A, B, C, D and E, each a non-empty string), "
    "ticket_update (string) and handover (string). "
    "Section A is the symptom and business impact, B is the evidence considered, "
    "C is the approved knowledge guidance, D is ownership and escalation, and "
    "E is the next actions for the first-level team. "
    "Never include markdown fences, never invent evidence that is not provided, "
    "never propose destructive or permission-changing actions as automatic steps, "
    "and always include all five sections."
)

SECTION_LABELS = {
    "A": "Symptom and business impact",
    "B": "Evidence considered",
    "C": "Knowledge guidance",
    "D": "Ownership and escalation",
    "E": "Next actions",
}


def _llm_enabled() -> bool:
    """Decide whether the LLM path may be used for this request."""
    mode = str(config.LLM_ENABLED or "auto").strip().lower()
    if mode == "off":
        return False
    if mode == "on":
        return bool(config.LLM_API_KEY)
    return bool(config.LLM_API_KEY)


def _load_al_template(conn: sqlite3.Connection) -> tuple[str, str, str, str]:
    """Read the runtime AL config from demo_config, falling back to env defaults.

    Priority: template file > custom string in demo_config > env default >
    built-in system prompt.
    """
    al_type = ""
    al_system = ""
    al_user = ""
    al_file = config.AL_PROMPT_TEMPLATE_FILE

    row = conn.execute(
        "SELECT config_key, config_value FROM demo_config WHERE config_key IN (?, ?, ?, ?)",
        ("al_analysis_type", "al_system_prompt", "al_user_prompt", "al_template_file"),
    ).fetchall()
    for r in row:
        if r["config_key"] == "al_analysis_type":
            al_type = r["config_value"] or "standard"
        elif r["config_key"] == "al_system_prompt":
            al_system = r["config_value"] or ""
        elif r["config_key"] == "al_user_prompt":
            al_user = r["config_value"] or ""
        elif r["config_key"] == "al_template_file":
            al_file = r["config_value"] or ""

    if not al_type:
        al_type = config.AL_ANALYSIS_TYPE or "standard"
    if not al_system:
        al_system = config.AL_SYSTEM_PROMPT_TEMPLATE or ""
    if not al_user:
        al_user = config.AL_USER_PROMPT_TEMPLATE or ""

    if al_file:
        try:
            with open(al_file, "r", encoding="utf-8", errors="replace") as handle:
                al_system = handle.read()
            al_user = ""
        except Exception:  # noqa: BLE001
            al_file = ""

    return al_type, al_system, al_user, al_file


def _inject_fields(key: str, inc: dict, dec: dict | None) -> str:
    """Expand a {{incident.field}} / {{decision.field}} placeholder."""
    parts = [p.strip() for p in str(key or "").split(".") if p.strip()]
    if parts and parts[0] in ("incident", "decision"):
        root = parts.pop(0)
        cur = inc if root == "incident" else (dec or {})
    else:
        cur = inc
    for part in parts:
        if isinstance(cur, dict) and part in cur and cur[part] not in (None, ""):
            cur = cur[part]
        else:
            return ""
    return str(cur)


def _render_prompt(context: dict) -> tuple[str, str]:
    """Render the system and user prompts from the operator's configuration."""
    try:
        conn = loader_mod.connect(config.DATABASE_PATH)
    except Exception:  # noqa: BLE001
        conn = None
    try:
        if conn is not None:
            al_type, al_system, al_user, _ = _load_al_template(conn)
        else:
            al_type = config.AL_ANALYSIS_TYPE or "standard"
            al_system = config.AL_SYSTEM_PROMPT_TEMPLATE or ""
            al_user = config.AL_USER_PROMPT_TEMPLATE or ""
    finally:
        if conn is not None:
            conn.close()

    inc = context.get("incident") or {}
    dec = context.get("decision") or {}

    system_prompt = al_system or DEFAULT_SYSTEM_PROMPT

    if al_user:
        rendered = []
        for segment in al_user.split("{{"):
            if "}}" in segment:
                key, _, rest = segment.partition("}}")
                rendered.append(_inject_fields(key, inc, dec))
                rendered.append(rest)
            else:
                rendered.append(segment)
        user_prompt = "".join(rendered).strip()
        if user_prompt:
            return system_prompt, user_prompt

    evidence = "; ".join(
        f"{e.get('type')}:{e.get('ref')}" for e in (dec.get("evidence") or []))
    user_prompt = "\n".join([
        f"Analysis type: {al_type or 'standard'}",
        f"Incident: {inc.get('incident_id') or 'unknown'}",
        f"Application: {inc.get('application_name') or 'unknown'}",
        f"Business service: {inc.get('business_service') or 'unknown'}",
        f"Environment: {inc.get('environment') or 'unknown'}",
        f"Error code: {inc.get('error_code') or 'none'}",
        f"Severity: {inc.get('severity') or 'unknown'}",
        f"Short description: {inc.get('short_description') or ''}",
        f"Description: {inc.get('detailed_description') or ''}",
        f"Error message: {inc.get('error_message') or ''}",
        f"Business impact: {inc.get('business_impact') or ''}",
        f"Affected users: {inc.get('affected_users') or 0}",
        f"Current assignment group: {inc.get('current_assignment_group') or 'unknown'}",
        f"Proposed routing: {dec.get('routing') or ''}",
        f"Proposed team: {dec.get('proposed_team') or ''}",
        f"Confidence: {dec.get('confidence')} ({dec.get('band') or ''})",
        f"Capped: {', '.join(dec.get('caps') or [])}",
        f"Safety flags: {', '.join(dec.get('flags') or [])}",
        f"Missing fields: {', '.join(dec.get('missing') or [])}",
        f"Evidence: {evidence}",
    ])
    return system_prompt, user_prompt


def _call_llm(system_prompt: str, user_prompt: str) -> dict | None:
    """Call the configured chat-completions endpoint and parse the JSON reply."""
    if not config.LLM_API_KEY:
        return None
    body = json.dumps({
        "model": config.LLM_MODEL,
        "temperature": 0,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }).encode("utf-8")
    request = urllib.request.Request(
        config.LLM_BASE_URL + "/chat/completions",
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.LLM_API_KEY}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=config.LLM_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError):
        return None
    try:
        content = payload["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        return None
    if isinstance(content, dict):
        return content
    try:
        return json.loads(str(content))
    except (TypeError, ValueError):
        return None


def _clean_text(value) -> str:
    return str(value or "").strip()


def _validate_narrative(payload: dict | None, fallback: dict) -> dict | None:
    """Accept an LLM payload only when it is well formed and safe to show."""
    if not isinstance(payload, dict):
        return None
    raw_sections = payload.get("sections")
    if not isinstance(raw_sections, dict):
        return None
    sections = {}
    for key in ("A", "B", "C", "D", "E"):
        text = _clean_text(raw_sections.get(key))
        if len(text) < 20:
            return None
        sections[key] = text
    ticket_update = _clean_text(payload.get("ticket_update"))
    handover = _clean_text(payload.get("handover"))
    if len(ticket_update) < 10 or len(handover) < 10:
        return None
    lowered = " ".join([*sections.values(), ticket_update, handover]).lower()
    for pattern in config.PROMPT_INJECTION_PATTERNS:
        if pattern in lowered:
            return None
    summary = _clean_text(payload.get("summary")) or sections["A"]
    return {
        "summary": summary,
        "sections": sections,
        "ticket_update": ticket_update,
        "handover": handover,
    }


def _rule_based_narrative(context: dict, style: str = "standard") -> dict:
    """Deterministic narrative used whenever the LLM path is unavailable."""
    inc = context.get("incident") or {}
    dec = context.get("decision") or {}

    incident_id = inc.get("incident_id") or "the incident"
    app = inc.get("application_name") or "the affected application"
    code = inc.get("error_code") or "no error code recorded"
    description = inc.get("detailed_description") or inc.get("short_description") or ""
    impact = inc.get("business_impact") or "business impact not stated"
    users = inc.get("affected_users") or 0
    severity = inc.get("severity") or "unclassified severity"
    routing = dec.get("routing") or "MANUAL_REVIEW"
    team = dec.get("proposed_team") or "no owning team evidenced"
    band = dec.get("band") or "low"
    confidence = dec.get("confidence")
    caps = dec.get("caps") or []
    flags = dec.get("flags") or []
    missing = dec.get("missing") or []
    duplicate_of = dec.get("duplicate_of") or ""
    abstain = bool(dec.get("abstain"))
    evidence = dec.get("evidence") or []

    section_a = (
        f"{app} raised {code} in {inc.get('environment') or 'the demo environment'} "
        f"with {severity}. The ticket describes: {description or 'no detailed description supplied'}. "
        f"Reported business impact: {impact}; {users} user(s) reported as affected. "
        f"The incident is currently assigned to "
        f"{inc.get('current_assignment_group') or 'an unassigned group'}."
    )

    if evidence:
        evidence_lines = "; ".join(
            f"{e.get('type', 'evidence')} ({e.get('ref', '')}): {e.get('detail', '')}"
            for e in evidence)
    else:
        evidence_lines = "No historical record, knowledge article or ownership entry was cited."
    caveats = []
    if missing:
        caveats.append("missing ticket fields: " + ", ".join(missing))
    if caps:
        caveats.append("confidence caps applied: " + ", ".join(caps))
    if flags:
        caveats.append("safety flags raised: " + ", ".join(flags))
    if duplicate_of:
        caveats.append(f"the ticket looks like a duplicate of open ticket {duplicate_of}")
    section_b = "Evidence consulted: " + evidence_lines
    if caveats:
        section_b += ". Caveats: " + "; ".join(caveats) + "."

    kb_types = {e.get("type") for e in evidence}
    if "kb_article" in kb_types:
        section_c = (
            "Only the approved knowledge article cited in the evidence may be used as "
            "guidance. Follow its steps in order and stop if a step needs a change record "
            "or owner approval."
        )
    elif "no_kb_statement" in kb_types:
        section_c = (
            "No approved knowledge article covers this symptom. Do not improvise from draft "
            "or outdated articles; record the gap so the knowledge team can review it."
        )
    else:
        section_c = (
            "No approved article is attached to this decision. Treat the runbook as "
            "unverified until a knowledge owner confirms the guidance for this application."
        )
    if "draft_kb_rejected" in flags:
        section_c += " A matching draft article was deliberately rejected and must not be used."
    if "outdated_kb_warning" in flags:
        section_c += " An outdated article was found and is shown as a warning only."
    if "destructive_action_requires_authorization" in flags:
        section_c += (
            " Any production-impacting step from the cited article requires an approved "
            "change record and owner sign-off before it may run."
        )

    if abstain:
        section_d = (
            f"The engine abstained and recommends {routing}: {dec.get('abstain_reason') or 'human judgement is required'}. "
            f"Wealth Application Support should keep ownership until an operator confirms the destination."
        )
    else:
        section_d = (
            f"The engine recommends {routing} to {team} with {band} confidence "
            f"({confidence if confidence is not None else 'n/a'}/100). "
            f"Wealth Application Support remains accountable for the first-level triage and "
            f"for confirming the handover with the receiving team."
        )
    if "security_escalation" in flags:
        section_d += (
            " Cybersecurity Operations owns containment decisions; the service desk must not "
            "unlock, block or change any account."
        )
    if "access_control_refusal" in flags:
        section_d += " No access control may be bypassed outside the approved request workflow."

    next_actions = [
        f"Confirm the reported symptom with the requester and re-check {code} in the application log.",
        "Capture the exact timestamp, host and correlation ID so the receiving team can trace the request.",
        f"Verify the ownership reference for {app} before routing the ticket onward.",
    ]
    if not inc.get("error_code"):
        next_actions.append("Ask the requester for the error code or a log excerpt; it is missing from the ticket.")
    if duplicate_of:
        next_actions.append(f"Link this ticket to {duplicate_of} instead of investigating twice.")
    if abstain:
        next_actions.append("Keep the ticket in Wealth Application Support and request a manual routing decision.")
    else:
        next_actions.append(f"Hand over to {team} with the evidence summary once the operator approves the routing.")
    if "destructive_action_requires_authorization" in flags:
        next_actions.append("Do not run any production-impacting remediation without an approved change record.")
    section_e = " ".join(f"({i}) {step}" for i, step in enumerate(next_actions, start=1))

    sections = {"A": section_a, "B": section_b, "C": section_c, "D": section_d, "E": section_e}

    if style == "concise":
        sections = {
            "A": f"{app}: {code}. Impact: {impact}. Severity {severity}.",
            "B": f"Evidence: {evidence_lines[:400]}",
            "C": section_c,
            "D": f"Route: {routing} to {team} ({band} confidence).",
            "E": f"(1) Verify the symptom. (2) Capture logs. (3) Route to {team} after approval.",
        }
    elif style == "verbose":
        sections["B"] = section_b + (
            f" Analysis latency and provider details are recorded in the audit trail for incident {incident_id}."
        )
        sections["D"] = section_d + " Every routing change is logged against the incident."
    elif style == "manual-first":
        sections["D"] = (
            "Manual decision required before any routing: the engine only proposes a destination. "
            + section_d
        )

    ticket_update = (
        f"Triage completed for {incident_id}: {routing} to {team} at {band} confidence. "
        f"Evidence: {', '.join(sorted(t for t in kb_types if t)) or 'none cited'}. "
        + ("Operator approval is required before handover." if abstain or routing != "RETAIN_WITH_WEALTH"
           else "Wealth Application Support keeps ownership; no handover required.")
    )
    handover = (
        f"Handover {incident_id} ({app}, {code}, {severity}) from Wealth Application Support to {team}. "
        f"Recommended routing: {routing} at {band} confidence"
        f"{'; capped: ' + ', '.join(caps) if caps else ''}. "
        f"First action for the receiving team: confirm the symptom and review the evidence listed in section B."
    )

    return {
        "summary": f"{app} - {code}: {routing} to {team} ({band} confidence).",
        "sections": sections,
        "ticket_update": ticket_update,
        "handover": handover,
    }


def generate_narrative(context: dict) -> dict:
    """Return the narrative for one analysis: LLM first, rule-based fallback.

    The return value is ``{"narrative": {...}, "provider": "<name>"}`` where the
    narrative carries ``summary``, ``sections`` (A-E), ``ticket_update`` and
    ``handover``.
    """
    try:
        conn = loader_mod.connect(config.DATABASE_PATH)
    except Exception:  # noqa: BLE001
        conn = None
    try:
        if conn is not None:
            style, _, _, _ = _load_al_template(conn)
        else:
            style = config.AL_ANALYSIS_TYPE or "standard"
    finally:
        if conn is not None:
            conn.close()

    fallback = _rule_based_narrative(context, style)

    if not _llm_enabled():
        return {"narrative": fallback, "provider": "rule_based_fallback"}

    try:
        system_prompt, user_prompt = _render_prompt(context)
        payload = _call_llm(system_prompt, user_prompt)
        narrative = _validate_narrative(payload, fallback)
        if narrative:
            if style == "concise" and narrative.get("sections"):
                narrative["sections"] = {
                    k: v if len(v) <= 320 else v[:317].rstrip() + "..."
                    for k, v in narrative["sections"].items()
                }
            return {"narrative": narrative, "provider": f"llm:{config.LLM_MODEL}"}
    except Exception:  # noqa: BLE001
        pass

    return {"narrative": fallback, "provider": "rule_based_fallback"}
