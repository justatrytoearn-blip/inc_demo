"""Routing recommendation engine for the POC.

Produces one of four explicit recommendations:
  RETAIN_WITH_WEALTH | REASSIGN_TO_ANOTHER_TEAM | MANUAL_REVIEW | COLLABORATIVE_INVESTIGATION

Method (transparent, documented heuristic - NOT a calibrated model):
  1. safety gates first: security incidents, critical missing information,
     unsupported (novel) incidents and draft-only knowledge always abstain
  2. two distinct fault domains (several error codes -> several teams)
     produce a collaborative investigation with a named primary team
  3. conflicting evidence (split historical ownership, or ownership matrix
     disagreeing with credible history) forces manual review - no guessing
  4. otherwise route to the evidenced owning team and compare with the
     current assignment group to decide retain vs reassign

Confidence policy (demonstration thresholds, NOT validated production values):
  * high   >= config.HIGH_CONFIDENCE_MIN
  * medium >= config.MEDIUM_CONFIDENCE_MIN
  * low    below that
  documented caps force at most medium: missing application, no application
  scoped history, workaround-only closest match, critical severity, risky
  knowledge action, ambiguous ownership matrix, previous fix that failed.
"""
from __future__ import annotations

import fnmatch
import re

import pandas as pd

import config
from services import knowledge as knowledge_service
from services import matcher as matcher_service

ROUTING_RETAIN = "RETAIN_WITH_WEALTH"
ROUTING_REASSIGN = "REASSIGN_TO_ANOTHER_TEAM"
ROUTING_MANUAL = "MANUAL_REVIEW"
ROUTING_COLLABORATIVE = "COLLABORATIVE_INVESTIGATION"

MISSING_FIELD_LABELS = {
    "application_name": "application name",
    "business_service": "business service",
    "error_code": "error code",
    "error_message": "error message / log excerpt",
    "environment": "environment",
}

REOPENED_TEXT_RE = re.compile(
    r"reopened|previous fix (?:did not|failed|has failed)|fix did not hold|"
    r"failed fix|previous fix appears to have failed|did not hold",
    re.I,
)


def split_list(value: str) -> list[str]:
    return [v.strip() for v in str(value or "").replace(",", "|").split("|") if v.strip()]


def matrix_code_patterns(ownership: pd.DataFrame) -> list[str]:
    patterns = []
    for _, row in ownership.iterrows():
        for pattern in split_list(row.get("common_error_patterns", "")):
            pat = pattern.strip().lower()
            if pat and pat not in patterns:
                patterns.append(pat)
    return patterns


def matrix_teams_for_code(ownership: pd.DataFrame, code: str) -> list[str]:
    """Teams whose common_error_patterns match the incident error code."""
    code = (code or "").strip().lower()
    if not code:
        return []
    teams = []
    for _, row in ownership.iterrows():
        for pattern in split_list(row.get("common_error_patterns", "")):
            pat = pattern.strip().lower()
            if not pat:
                continue
            if fnmatch.fnmatch(code, pat) or pat in code:
                teams.append(str(row["team_name"]))
                break
    return teams


def matrix_text_teams(ownership: pd.DataFrame, text: str) -> list[str]:
    """Teams reachable through non-code ownership patterns (substring)."""
    hits = []
    for _, row in ownership.iterrows():
        for pattern in split_list(row.get("common_error_patterns", "")):
            pat = pattern.strip().lower()
            if not pat:
                continue
            if pat in text:
                hits.append(str(row["team_name"]))
    return hits


def matrix_teams_for_app(ownership: pd.DataFrame, app: str) -> list[str]:
    app = (app or "").strip().lower()
    if not app:
        return []
    teams = []
    for _, row in ownership.iterrows():
        if app in [a.lower() for a in split_list(row.get("supported_applications", ""))]:
            teams.append(str(row["team_name"]))
    return teams


def ownership_entry(ownership: pd.DataFrame, team: str) -> dict:
    rows = ownership[ownership["team_name"] == team]
    if rows.empty:
        return {}
    row = rows.iloc[0]
    return {c: row.get(c, "") for c in ownership.columns}


def team_for_code(ownership: pd.DataFrame, history: pd.DataFrame,
                  kb_matches: list[dict], code: str) -> str | None:
    """Resolve one error code to a owning team: matrix -> history -> KB."""
    teams = matrix_teams_for_code(ownership, code)
    if len(teams) == 1:
        return teams[0]
    if code:
        scoped = history[history["error_code"].str.lower() == code.lower()]
        credible = matcher_service.credible(scoped)
        if not credible.empty:
            dist = matcher_service.team_distribution(credible)
            return matcher_service.dominant_team(dist)
        if len(teams) > 1:
            return None
    for article in kb_matches:
        codes = [c.strip().lower() for c in str(article.get("error_codes", "")).split("|")]
        if code and code.lower() in codes and article.get("escalation_team"):
            return str(article["escalation_team"]).split("(")[0].strip()
    return teams[0] if teams else None


def evidence(types_by_key: dict[str, dict]) -> list[dict]:
    return [
        {"type": key, **value}
        for key, value in types_by_key.items()
        if value is not None
    ]


class DecisionInputs:
    """Everything the decision function needs, computed once by the triage layer."""

    def __init__(self, incident: dict, ownership: pd.DataFrame, history: pd.DataFrame,
                 matcher: matcher_service.HistoryMatcher,
                 retriever: knowledge_service.KnowledgeRetriever,
                 open_tickets: list[dict] | None = None):
        self.incident = incident
        self.ownership = ownership
        self.history = history
        self.matcher = matcher
        self.open_tickets = open_tickets or []
        self.text = matcher_service.record_text(incident)
        self.codes = matcher_service.extract_error_codes(
            " ".join(str(incident.get(f, "") or "") for f in
                     ("short_description", "detailed_description", "error_code", "error_message"))
        )
        self.matches = matcher.match(incident, top_k=config.TOP_HISTORY_MATCHES)
        self.kb = retriever.search(incident)
        self.app = str(incident.get("application_name", "") or "").strip()
        self.code = str(incident.get("error_code", "") or "").strip()
        self.scoped, self.scope_label = matcher_service.scope_history(history, self.app, self.code)
        self.credible = matcher_service.credible(self.scoped)
        self.dist = matcher_service.team_distribution(self.credible)
        self.history_team = matcher_service.dominant_team(self.dist)
        self.matrix_code_teams = matrix_teams_for_code(ownership, self.code)
        self.matrix_text_teams = matrix_text_teams(ownership, self.text)
        self.matrix_app_teams = matrix_teams_for_app(ownership, self.app)

    # -- support ------------------------------------------------------------
    @property
    def code_history_count(self) -> int:
        if not self.code:
            return 0
        scoped = self.history[self.history["error_code"].str.lower() == self.code.lower()]
        return int(len(matcher_service.credible(scoped)))

    @property
    def app_history_count(self) -> int:
        return int(len(self.credible))

    @property
    def top_match_score(self) -> float:
        return self.matches[0]["score"] if self.matches else 0.0

    @property
    def best_credible_score(self) -> float:
        """Top score of the best *credible* historical match (evidence base)."""
        return self.matcher.best_credible_score(self.incident)

    @property
    def max_credible_score(self) -> float:
        """Highest score among credible matches (used by the match census)."""
        best = 0.0
        for m in self.matches:
            if m["credible"] and m["score"] > best:
                best = m["score"]
        return best

    @property
    def has_history_support(self) -> bool:
        return (self.code_history_count > 0
                or self.top_match_score >= matcher_service.TEXT_SUPPORT_MIN)

    @property
    def approved_kb(self) -> list[dict]:
        return self.kb["approved"]

    @property
    def kb_warnings(self) -> list[dict]:
        return self.kb["warnings"]

    def missing_fields(self) -> list[str]:
        missing = []
        for field in ("application_name", "business_service", "error_code", "error_message"):
            if not str(self.incident.get(field, "") or "").strip():
                missing.append(MISSING_FIELD_LABELS[field])
        if not str(self.incident.get("environment", "") or "").strip():
            missing.append(MISSING_FIELD_LABELS["environment"])
        return missing

    @property
    def exact_kb_codes(self) -> set[str]:
        found = set()
        for article in self.kb["approved"] + self.kb["warnings"]:
            codes = [c.strip().lower() for c in str(article.get("error_codes", "")).split("|")]
            for c in codes:
                if c:
                    found.add(c)
        return found


def _is_security_incident(incident: dict) -> bool:
    code = str(incident.get("error_code", "") or "").upper()
    if code.startswith("WM-SEC-"):
        return True
    text = " ".join(str(incident.get(f, "") or "") for f in
                    ("short_description", "detailed_description", "error_message")).lower()
    return any(keyword in text for keyword in config.SECURITY_KEYWORDS)


def _is_access_incident(incident: dict) -> bool:
    code = str(incident.get("error_code", "") or "").upper()
    if "WM-AUTH-403" in code:
        return True
    text = " ".join(str(incident.get(f, "") or "") for f in
                    ("short_description", "detailed_description", "error_message")).lower()
    return any(phrase in text for phrase in
               ("permission denied", "access denied", "grant the permission",
                "grant permission", "lacks role", "missing role"))


def _prompt_injection_hit(incident: dict) -> bool:
    text = " ".join(str(incident.get(f, "") or "") for f in
                    ("short_description", "detailed_description", "error_message")).lower()
    return any(pattern in text for pattern in config.PROMPT_INJECTION_PATTERNS)


def _matrix_conflict(inputs: DecisionInputs) -> bool:
    if not inputs.matrix_code_teams or not inputs.history_team:
        return False
    return inputs.history_team not in inputs.matrix_code_teams


def _score(inputs: DecisionInputs, caps: list[str], matrix_agrees: bool) -> int:
    """Transparent additive confidence score, then documented caps."""
    score = 45.0
    n_app = inputs.app_history_count
    n_code = inputs.code_history_count
    if n_app >= 5:
        score += 16
    elif n_app >= 1:
        score += 12
    elif n_code >= 5:
        score += 10
    elif n_code >= 1:
        score += 7

    score += 8.0 * min(1.0, inputs.best_credible_score / 0.55)

    if inputs.approved_kb:
        if any(a.get("exact_code") for a in inputs.approved_kb):
            score += 12
        else:
            score += 8

    if inputs.matrix_code_teams and len(inputs.matrix_code_teams) == 1:
        score += 8
    elif len(inputs.matrix_app_teams) == 1:
        score += 6
    elif len(inputs.matrix_app_teams) > 1:
        score += 2

    if matrix_agrees and inputs.matrix_code_teams and inputs.history_team:
        if inputs.history_team in inputs.matrix_code_teams:
            score += 6

    if inputs.history_team:
        ratio = matcher_service.permanent_ratio(inputs.credible, inputs.history_team)
        if ratio >= 0.7:
            score += 5
        elif ratio >= 0.4:
            score += 2

    if inputs.scope_label == "none" and inputs.history_team:
        score += 8  # decisive text-only history, no application scoped records

    score = min(score, 97.0)

    medium_caps = {
        "missing_application_information",
        "no_application_scoped_history",
        "missing_information",
        "workaround_only_history",
        "previous_fix_failed",
        "critical_severity",
        "risky_knowledge_action",
        "ambiguous_ownership_matrix",
    }
    if any(cap in medium_caps for cap in caps):
        score = min(score, float(config.HIGH_CONFIDENCE_MIN - 1))
    return round(score)


def band_for(confidence: float, abstain: bool) -> str:
    if abstain or confidence < config.MEDIUM_CONFIDENCE_MIN:
        return "low"
    if confidence >= config.HIGH_CONFIDENCE_MIN:
        return "high"
    return "medium"


def _abstain(ev: dict, flags: list[str], missing: list[str], *, reason: str,
             caps: list[str], proposed_team: str, escalation_contact: str) -> dict:
    if "draft_only_knowledge" in caps and "draft_kb_rejected" not in flags:
        flags.append("draft_kb_rejected")
    return dict(
        routing=ROUTING_MANUAL,
        proposed_team=proposed_team,
        secondary_team="",
        escalation_contact=escalation_contact,
        confidence=45,
        band="low",
        caps=caps,
        flags=flags,
        evidence=evidence(ev),
        missing=missing,
        abstain=True,
        abstain_reason=reason,
        primary_team_for_collab=None,
    )


def _find_duplicate(inputs: DecisionInputs) -> str:
    """Compare against other open tickets (exact app+code+message or near-identical text)."""
    incident = inputs.incident
    app = str(incident.get("application_name", "") or "").lower()
    code = str(incident.get("error_code", "") or "").lower()
    msg = matcher_service.normalize_text(str(incident.get("error_message", "") or ""))
    self_id = str(incident.get("incident_id", "") or "")
    for other in inputs.open_tickets:
        other_id = str(other.get("incident_id", ""))
        if not other_id or other_id == self_id:
            continue
        if str(other.get("status", "new")).lower() not in ("new", "open", "in_progress", "pending"):
            continue
        if app and code:
            same = (
                app == str(other.get("application_name", "") or "").lower()
                and code == str(other.get("error_code", "") or "").lower()
                and msg
                and msg == matcher_service.normalize_text(str(other.get("error_message", "") or ""))
            )
            if same:
                return other_id
    return ""


def decide(inputs: DecisionInputs) -> dict:
    """Return the routing decision with confidence, caps, flags and evidence."""
    incident = inputs.incident
    ev: dict[str, dict | None] = {}
    caps: list[str] = []
    flags: list[str] = []
    missing = inputs.missing_fields()
    current_group = str(incident.get("current_assignment_group", "") or "").strip()

    if _prompt_injection_hit(incident):
        flags.append("prompt_injection_detected")

    matrix_entry = ownership_entry(inputs.ownership, inputs.history_team) if inputs.history_team else {}

    # ownership reference is always cited (even when it cannot decide)
    ev["ownership_reference"] = {
        "ref": "ownership matrix",
        "detail": (
            f"Ownership matrix consulted for application "
            f"'{inputs.app or 'unknown'}' / error code '{inputs.code or 'none'}'."
        ),
    }

    # security gate
    if _is_security_incident(incident):
        flags.append("security_escalation")
        flags.append("no_account_action")
        ev["escalation_conditions"] = {
            "ref": "Cybersecurity Operations",
            "detail": "Cybersecurity Operations owns containment decisions; "
                      "no account unlock, block or control change from the service desk.",
        }
        return _abstain(
            ev, flags, missing,
            reason="Security-sensitive incident - human decision required.",
            caps=["security_sensitive_incident"],
            proposed_team="Cybersecurity Operations",
            escalation_contact="Cybersecurity Operations",
        )

    # access-control refusal
    if _is_access_incident(incident):
        flags.append("access_control_refusal")
        ev["escalation_conditions"] = {
            "ref": "Identity and Access Management",
            "detail": "No permission change outside the approved access request workflow; "
                      "do not bypass access controls.",
        }

    if missing:
        ev["missing_info"] = {
            "ref": "incident fields",
            "detail": "Missing from the ticket: " + ", ".join(missing),
        }

    # escalate: fastest path for low-signal cases, no team inferred
    esc_team = inputs.history_team or (inputs.matrix_code_teams[0] if inputs.matrix_code_teams else
                                       (inputs.matrix_app_teams[0] if len(inputs.matrix_app_teams) == 1 else ""))
    if esc_team and esc_team != "unknown":
        entry = ownership_entry(inputs.ownership, esc_team)
        if entry and entry.get("escalation_conditions"):
            ev["escalation_conditions"] = {
                "ref": esc_team,
                "detail": str(entry.get("escalation_conditions", "")).strip(),
            }

    code_supported = inputs.code_history_count > 0

    # critical missing information
    if "application name" in missing and "error code" in missing:
        ev["no_kb_statement"] = {
            "ref": "knowledge base",
            "detail": "No approved knowledge article matches this incident.",
        }
        return _abstain(
            ev, flags, missing,
            reason="Critical information missing - application and error code unknown.",
            caps=["critical_missing_information"],
            proposed_team="",
            escalation_contact="",
        )
    if "application name" in missing and not inputs.has_history_support:
        ev["no_kb_statement"] = {
            "ref": "knowledge base",
            "detail": "No approved knowledge article matches this incident.",
        }
        return _abstain(
            ev, flags, missing,
            reason="Application unknown and no supported historical or knowledge evidence.",
            caps=["critical_missing_information"],
            proposed_team="",
            escalation_contact="",
        )

    # novelty / unsupported
    unknown_code = (
        bool(inputs.code)
        and inputs.code_history_count == 0
        and inputs.code not in inputs.exact_kb_codes
        and not inputs.matrix_code_teams
        and not inputs.matrix_text_teams
    )
    if unknown_code and not inputs.has_history_support:
        ev["no_kb_statement"] = {
            "ref": "knowledge base",
            "detail": "No approved knowledge article matches this incident.",
        }
        return _abstain(
            ev, flags, missing,
            reason="Unrecognised error code with no historical or knowledge support.",
            caps=["unknown_error_code"],
            proposed_team="",
            escalation_contact="",
        )

    # draft-only knowledge
    # only articles keyed to this error code count as 'exact' - the KB
    # entry carries exact_code so we do not re-parse error_codes here
    any_exact = [a for a in inputs.kb["approved"] + inputs.kb["warnings"]
                 if inputs.code and a.get("exact_code")]
    if inputs.code and any_exact and not any(
            a["status"] == "approved" for a in any_exact
    ) and not code_supported:
        for a in any_exact:
            if a["status"] == "draft":
                flags.append("draft_kb_rejected")
            else:
                flags.append("outdated_kb_warning")
        ev["no_kb_statement"] = {
            "ref": "knowledge base",
            "detail": "The only articles keyed to this error code are not approved for use "
                      "(draft or outdated). No approved guidance exists; the agent abstains.",
        }
        return _abstain(
            ev, flags, missing,
            reason="Only non-approved knowledge exists for this incident.",
            caps=["draft_only_knowledge"],
            proposed_team="",
            escalation_contact="",
        )

    # support checks
    if inputs.code_history_count > 0 or inputs.best_credible_score >= matcher_service.TEXT_SUPPORT_MIN:
        best = None
        for m in inputs.matches:
            if m["credible"]:
                best = m
                break
        if best is None and inputs.top_match_score > 0:
            best = inputs.matches[0]
        if best is not None:
            ev["historical_match"] = {
                "ref": best["incident_id"],
                "detail": (f"Similar historical record {best['incident_id']} (score {best['score']}, "
                           f"resolved by {best['final_resolver_team']}, "
                           f"{best['resolution_status']})."),
            }
    if inputs.approved_kb:
        a = inputs.approved_kb[0]
        ev["kb_article"] = {
            "ref": a.get("article_id", ""),
            "detail": (f"Approved article {a.get('article_id', '')} - "
                       f"{a.get('title', '')}."),
        }
    if not inputs.approved_kb:
        ev["no_kb_statement"] = {
            "ref": "knowledge base",
            "detail": "No approved knowledge article matches this incident.",
        }

    # two fault domains -> collaborative
    code_team_pairs: list[tuple[str, str]] = []
    for code in inputs.codes:
        team = team_for_code(inputs.ownership, inputs.history, inputs.kb["approved"], code)
        if team and (code, team) not in code_team_pairs:
            code_team_pairs.append((code, team))
    teams_in_text = {t for _, t in code_team_pairs}
    primary_code = inputs.code or (inputs.codes[0] if inputs.codes else "")
    primary_team = next((t for c, t in code_team_pairs if c == primary_code), None)
    if primary_team is None and code_team_pairs:
        primary_team = code_team_pairs[0][1]

    if len(teams_in_text) >= 2 and primary_team:
        secondary = next(t for _, t in code_team_pairs if t != primary_team)
        return dict(
            routing=ROUTING_COLLABORATIVE,
            proposed_team=primary_team,
            secondary_team=secondary,
            escalation_contact="",
            confidence=_score(inputs, caps, matrix_agrees=True),
            band="",
            caps=caps,
            flags=flags,
            evidence=evidence(ev),
            missing=missing,
            abstain=False,
            abstain_reason="",
            primary_team_for_collab=primary_team,
            collab_teams=[t for _, t in code_team_pairs],
        )

    # keep the split check standalone
    split = matcher_service.detect_split(inputs.dist)
    if split:
        detail = ("Conflicting historical evidence: credible six-month records for "
                  f"this application and error code were closed successfully by "
                  f"{len(inputs.dist)} different teams "
                  f"({', '.join(f'{k}: {v}' for k, v in sorted(inputs.dist.items()))}). "
                  "The agent abstains instead of taking a majority vote.")
        ev["conflict_statement"] = {"ref": "evidence conflict", "detail": detail}

    matrix_conflict = bool(inputs.matrix_code_teams and inputs.history_team
                           and inputs.scope_label != "none" and _matrix_conflict(inputs))
    if matrix_conflict:
        detail = (f"Conflicting ownership evidence: the ownership matrix points to "
                  f"{', '.join(inputs.matrix_code_teams)} for '{inputs.code}' but credible "
                  f"history for {inputs.app or 'this application'} shows "
                  f"{inputs.history_team} closing similar incidents. Manual review required.")
        ev["conflict_statement"] = {"ref": "evidence conflict", "detail": detail}

    if split or matrix_conflict:
        return dict(
            routing=ROUTING_MANUAL,
            proposed_team="",
            secondary_team="",
            escalation_contact="",
            confidence=45, band="low",
            caps=["conflicting_evidence"],
            flags=flags,
            evidence=evidence(ev),
            missing=missing,
            abstain=True,
            abstain_reason="Conflicting ownership evidence.",
            primary_team_for_collab=None,
        )

    # route to the evidenced owner
    proposed_team = inputs.history_team
    if proposed_team is None:
        if len(inputs.matrix_code_teams) == 1:
            proposed_team = inputs.matrix_code_teams[0]
        elif len(inputs.matrix_app_teams) == 1:
            proposed_team = inputs.matrix_app_teams[0]
        elif inputs.kb["approved"]:
            proposed_team = str(inputs.kb["approved"][0].get("escalation_team", "")).split("(")[0].strip() or None

    if not inputs.matrix_code_teams and len(inputs.matrix_app_teams) > 1:
        caps.append("ambiguous_ownership_matrix")
    if not inputs.app:
        caps.append("missing_application_information")
    if inputs.scope_label != "app+code":
        caps.append("no_application_scoped_history")
    if missing:
        caps.append("missing_information")

    # caveats on the closest credible outcome
    if inputs.history_team is not None and not inputs.credible.empty:
        top_rows = inputs.credible
        workaround_share = float(
            top_rows["resolution_status"].str.contains("Workaround", case=False, na=False).sum()
        ) / float(len(top_rows))
        if workaround_share >= 0.6:
            caps.append("workaround_only_history")
            ev["workaround_note"] = {
                "ref": "closest historical resolution",
                "detail": "The closest previous resolutions were closed as temporary "
                          "workarounds, not permanent fixes - confidence capped at medium.",
            }
        if inputs.code:
            reopened_rows = inputs.history[
                (inputs.history["error_code"].str.lower() == inputs.code.lower())
                & (inputs.history["resolution_status"].str.contains("Reopened", case=False, na=False)
                   | inputs.history["historical_record_quality"].eq("contradictory"))
            ]
        else:
            reopened_rows = inputs.history.iloc[0:0]
        if len(reopened_rows) > 0:
            ev["reopened_note"] = {
                "ref": "previous resolution records",
                "detail": f"{len(reopened_rows)} previous record(s) for this error were reopened "
                          "or marked contradictory and are excluded from confident evidence.",
            }
            if REOPENED_TEXT_RE.search(str(incident.get("detailed_description", ""))
                                       + " " + str(incident.get("short_description", ""))):
                # Only cap when reopened/contradictory records are a substantial
                # share of the evidence base: they signal a previous fix that
                # failed and the confident signal must come from the remaining
                # (cleaned) set. The reopened records themselves are always
                # excluded from confident evidence via reopened_note.
                try:
                    app_cells = (
                        (inputs.history["application_name"].str.lower() == inputs.app.lower())
                        & (inputs.history["error_code"].str.lower() == inputs.code.lower())
                    )
                    app_code_hist = inputs.history[app_cells]
                    reopened = int(
                        app_code_hist[
                            app_code_hist["resolution_status"].str.contains(
                                "Reopened", case=False, na=False)
                        ].shape[0]
                    )
                    if reopened >= 5:
                        caps.append("previous_fix_failed")
                except Exception:  # noqa: BLE001
                    pass

    severity = str(incident.get("severity", "") or "")
    if severity.startswith("1"):
        caps.append("critical_severity")

    risky = next((a for a in inputs.approved_kb if a.get("risky_action")), None)
    if risky:
        caps.append("risky_knowledge_action")
        flags.append("destructive_action_requires_authorization")
        ev["escalation_conditions"] = {
            "ref": risky.get("article_id", ""),
            "detail": (f"Article {risky.get('article_id', '')} proposes a production-impacting "
                       f"step ('{risky['risky_action']['step']}') that requires an approved "
                       "change record and owner sign-off before it may run - never as an "
                       "unattended action."),
        }

    if inputs.kb["warnings"]:
        flags.append("outdated_kb_warning")

    duplicate_of = _find_duplicate(inputs)
    if duplicate_of:
        ev["duplicate_flag"] = {
            "ref": duplicate_of,
            "detail": f"Looks like a duplicate of open ticket {duplicate_of}.",        }
    if inputs.history_team and inputs.matrix_code_teams and proposed_team in inputs.matrix_code_teams:
        matrix_agrees = True
    else:
        matrix_agrees = bool(inputs.history_team is None or proposed_team is None) or not inputs.matrix_code_teams

    if not proposed_team:
        return _abstain(
            ev, flags, missing,
            reason="No owning team could be evidenced.",
            caps=caps + ["no_owning_team"],
            proposed_team="",
            escalation_contact="",
        )

    routing = ROUTING_RETAIN if (current_group and proposed_team == current_group) else ROUTING_REASSIGN

    return dict(
        routing=routing,
        proposed_team=proposed_team,
        secondary_team="",
        escalation_contact="",
        confidence=_score(inputs, caps, matrix_agrees=matrix_agrees),
        band="",
        caps=caps,
        flags=flags,
        evidence=evidence(ev),
        missing=missing,
        abstain=False,
        abstain_reason="",
        duplicate_of=duplicate_of,
    )
