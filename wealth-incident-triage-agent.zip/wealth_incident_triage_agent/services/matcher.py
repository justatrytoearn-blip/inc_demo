"""Historical incident matching for the POC.

Transparent heuristic - NOT a calibrated model:
  * character + word TF-IDF cosine similarity over normalised incident text
  * credibility filter: contradictory records and reopened records never count
    as confident evidence (they are still shown, clearly labelled)
  * scoped evidence sets (app+code -> code -> text search) used for routing

All data is SYNTHETIC DEMO DATA.
"""
from __future__ import annotations

import re
from collections import Counter

import numpy as np
import pandas as pd
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

import config

# Error codes used across the synthetic estate (WM-CERT-EXP has no digits).
CODE_RE = re.compile(r"\bWM-[A-Z]{2,10}(?:-[A-Z0-9]{1,10}){1,2}\b")
ORA_RE = re.compile(r"\bORA-\d{4,6}\b")

WS_RE = re.compile(r"\s+")
PUNCT_RE = re.compile(r"[^0-9a-zA-Z_./:-]+")

CREDIBLE_QUALITY = {"good", "partial"}
NON_CREDIBLE_STATUS = {"Reopened"}

TEXT_SUPPORT_MIN = 0.30  # cosine below this counts as "no historical support"


def normalize_text(text: str) -> str:
    """Lowercase, strip punctuation noise, collapse whitespace."""
    text = (text or "").lower()
    text = PUNCT_RE.sub(" ", text)
    return WS_RE.sub(" ", text).strip()


def extract_error_codes(text: str) -> list[str]:
    """Ordered de-duplicated error codes found in free text."""
    seen: list[str] = []
    for match in CODE_RE.findall(text or ""):
        if match not in seen:
            seen.append(match)
    for match in ORA_RE.findall(text or ""):
        if match not in seen:
            seen.append(match)
    return seen


def record_text(record: pd.Series | dict) -> str:
    """Canonical searchable text for one historical/incoming incident."""
    get = record.get
    parts = [
        get("short_description", ""),
        get("detailed_description", ""),
        get("error_code", ""),
        get("error_message", ""),
        get("application_name", ""),
        get("business_service", ""),
        get("root_cause", ""),
        get("resolution_summary", ""),
        get("previous_troubleshooting", ""),
    ]
    return normalize_text(" ".join(str(p) for p in parts if p))


def is_credible(row: pd.Series | dict) -> bool:
    """Contradictory records and reopened records are not confident evidence."""
    quality = str(row.get("historical_record_quality", "good")).strip().lower()
    status = str(row.get("resolution_status", "")).strip()
    return quality in CREDIBLE_QUALITY and status not in NON_CREDIBLE_STATUS


class HistoryMatcher:
    """TF-IDF cosine matcher over the six-month historical evidence base."""

    def __init__(self, history: pd.DataFrame):
        self.history = history.copy().reset_index(drop=True)
        if self.history.empty:
            self._corpus_matrix = None
            self._texts: list[str] = []
            return
        self._texts = [record_text(row) for _, row in self.history.iterrows()]
        self._word = TfidfVectorizer(
            lowercase=True, ngram_range=(1, 2), sublinear_tf=True, min_df=1
        )
        self._char = TfidfVectorizer(
            analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True, min_df=1,
            lowercase=True,
        )
        x_word = self._word.fit_transform(self._texts)
        x_char = self._char.fit_transform(self._texts)
        self._corpus_matrix = normalize(hstack([x_word, x_char]), norm="l2", axis=1)
        self._credibility = np.array([is_credible(r) for _, r in self.history.iterrows()])

    # -- queries -----------------------------------------------------------
    def _vectorize(self, text: str):
        if self._corpus_matrix is None:
            return None
        norm = normalize_text(text)
        x = hstack([self._word.transform([norm]), self._char.transform([norm])])
        return normalize(x, norm="l2", axis=1)

    def match(self, query_record: dict | pd.Series, top_k: int | None = None,
              min_score: float = 0.0) -> list[dict]:
        """Top-K similar historical incidents with similarity scores.

        Credible records (good/partial quality, not reopened) are returned first;
        non-credible records are only appended once the credible budget is met.
        """
        top_k = top_k or config.TOP_HISTORY_MATCHES
        if self._corpus_matrix is None:
            return []
        query = record_text(query_record)
        if not query.strip():
            return []
        vec = self._vectorize(query)
        scores = (self._corpus_matrix @ vec.T).toarray().ravel()
        order = np.argsort(scores)[::-1]
        credible_indices: list[int] = []
        non_credible_indices: list[int] = []
        for idx in order:
            if int(self._credibility[idx]):
                credible_indices.append(int(idx))
            else:
                non_credible_indices.append(int(idx))
            if len(credible_indices) >= max(top_k, 5) and len(non_credible_indices) >= 3:
                break
        results: list[dict] = []
        for idx in credible_indices:
            score = float(scores[idx])
            if score < min_score:
                continue
            row = self.history.iloc[idx]
            results.append({
                "incident_id": row.get("incident_id", ""),
                "score": round(score, 4),
                "application_name": row.get("application_name", ""),
                "error_code": row.get("error_code", ""),
                "final_resolver_team": row.get("final_resolver_team", ""),
                "resolution_status": row.get("resolution_status", ""),
                "resolution_summary": row.get("resolution_summary", ""),
                "root_cause": row.get("root_cause", ""),
                "knowledge_article_id": row.get("knowledge_article_id", ""),
                "historical_record_quality": row.get("historical_record_quality", "good"),
                "credible": True,
                "closed_at": row.get("closed_at", ""),
            })
            if len(results) >= top_k:
                break
        if len(results) < top_k:
            for idx in non_credible_indices:
                if len(results) >= top_k:
                    break
                score = float(scores[idx])
                if score < min_score:
                    continue
                row = self.history.iloc[idx]
                results.append({
                    "incident_id": row.get("incident_id", ""),
                    "score": round(score, 4),
                    "application_name": row.get("application_name", ""),
                    "error_code": row.get("error_code", ""),
                    "final_resolver_team": row.get("final_resolver_team", ""),
                    "resolution_status": row.get("resolution_status", ""),
                    "resolution_summary": row.get("resolution_summary", ""),
                    "root_cause": row.get("root_cause", ""),
                    "knowledge_article_id": row.get("knowledge_article_id", ""),
                    "historical_record_quality": row.get("historical_record_quality", "good"),
                    "credible": False,
                    "closed_at": row.get("closed_at", ""),
                })
        return results

    def best_credible_score(self, query_record: dict | pd.Series) -> float:
        """Cosine score of the best *credible* historical match (evidence base).

        Non-credible records are excluded from the evidence score so reopened or
        contradictory records cannot inflate (or suppress) confidence.
        """
        if self._corpus_matrix is None:
            return 0.0
        query = record_text(query_record)
        if not query.strip():
            return 0.0
        vec = self._vectorize(query)
        scores = (self._corpus_matrix @ vec.T).toarray().ravel()
        import config as _cfg
        best = 0.0
        for idx in np.argsort(scores)[::-1]:
            if bool(self._credibility[idx]) and scores[idx] > best:
                best = float(scores[idx])
                if best >= getattr(_cfg, 'TEXT_SUPPORT_MIN', 0.30):
                    break
        return best

    def top_score(self, query_record: dict | pd.Series) -> float:
        """Top score of any historical match (including non-credible records)."""
        matches = self.match(query_record, top_k=1)
        return matches[0]["score"] if matches else 0.0
        matches = self.match(query_record, top_k=1)
        return matches[0]["score"] if matches else 0.0


# ---------------------------------------------------------------------------
# Evidence scoping helpers (shared by the recommendation engine)
# ---------------------------------------------------------------------------
def credible(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    mask = df.apply(is_credible, axis=1)
    return df[mask]


def scope_history(history: pd.DataFrame, app: str, code: str) -> tuple[pd.DataFrame, str]:
    """Evidence scope: app+code -> code (global) -> none."""
    app = (app or "").strip()
    code = (code or "").strip()
    if app:
        scoped = history[history["application_name"].str.lower() == app.lower()]
        if code:
            by_code = scoped[scoped["error_code"].str.lower() == code.lower()]
            if not by_code.empty:
                return by_code, "app+code"
    if code:
        by_code = history[history["error_code"].str.lower() == code.lower()]
        if not by_code.empty:
            return by_code, "code"
    return history.iloc[0:0], "none"


def team_distribution(df: pd.DataFrame) -> dict[str, int]:
    if df.empty:
        return {}
    return dict(Counter(df["final_resolver_team"].astype(str).tolist()))


def dominant_team(distribution: dict[str, int]) -> str | None:
    if not distribution:
        return None
    return max(distribution.items(), key=lambda kv: kv[1])[0]


def detect_split(distribution: dict[str, int]) -> bool:
    """Two credible resolver teams with genuinely competing outcomes."""
    if len(distribution) < 2:
        return False
    total = sum(distribution.values())
    if total < 6:
        return False
    ordered = sorted(distribution.values(), reverse=True)
    top_share = ordered[0] / total
    second_share = ordered[1] / total
    return top_share <= 0.70 and second_share >= 0.25 and ordered[1] >= 3


def permanent_ratio(df: pd.DataFrame, team: str | None) -> float:
    if df.empty or not team:
        return 0.0
    team_rows = df[df["final_resolver_team"] == team]
    if team_rows.empty:
        return 0.0
    permanent = team_rows["resolution_status"].str.contains("Permanent", case=False, na=False)
    return float(permanent.sum()) / float(len(team_rows))
