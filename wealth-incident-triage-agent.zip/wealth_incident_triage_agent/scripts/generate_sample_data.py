"""Generate the synthetic demo datasets for the Wealth Incident Triage Agent POC.

Produces (all SYNTHETIC DEMO DATA, deterministic with seed 20261024):
    data/historical_incidents.csv   >= 300 incidents covering the last six months
    data/incoming_incidents.csv     new incidents for the queue / demo selector
    data/knowledge_base.csv         >= 40 knowledge articles
    data/team_ownership.csv         current ownership matrix
    data/test_scenarios.csv         >= 40 labeled test scenarios (labels are for
                                    the evaluation script only, never for the engine)

Run from the project root:
    .venv/Scripts/python.exe scripts/generate_sample_data.py
"""
from __future__ import annotations

import csv
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from sample_data_defs import ARCHETYPES, SYNTHETIC_LABEL, TEAMS, SYMPTOM_VARIANTS, TYPO_MAP  # noqa: E402
from knowledge_defs import KB_ARTICLES  # noqa: E402
from scenario_defs import DEMO_INCIDENTS, SCENARIOS  # noqa: E402

DATA_DIR = ROOT / "data"
SEED = 20261024
HISTORICAL_COUNT = 340
EXTRA_INCOMING_COUNT = 14
HISTORY_DAYS = 183

# Relative frequency of each archetype in the six-month history.
WEIGHTS = {
    "db_conn": 16, "db_lock": 9, "db_lock_drift": 7, "db_deadlock": 12, "db_slow": 7,
    "mq_backlog": 12, "mq_poison": 8, "api_timeout": 14, "api_timeout_vendor": 7,
    "auth_401": 14, "auth_403": 9, "lockout": 8, "net_timeout": 10, "cert_expiry": 11,
    "cpu_exhaustion": 10, "disk_exhaustion": 7, "mem_exhaustion": 6,
    "batch_fail": 12, "report_delay": 9, "warehouse_delay": 7, "market_data_missing": 11,
    "trade_delay": 11, "trade_validation": 8, "recon_mismatch": 6,
    "payment_stuck": 9, "vendor_sftp": 6, "sec_burst": 5,
    "cfg_drift": 12, "perf_slow": 8, "perf_app_pp": 7, "perf_infra_pp": 7,
    "onboard_fail": 9, "portal_js": 7, "rate_limit": 6, "session_timeout": 6,
    "profile_load": 7, "legacy_job": 4, "access_provision": 4,
    "auth_403_local": 12, "payment_reopened": 5, "db_conn_bad_history": 4,
}

SEVERITIES = ["1 - Critical", "2 - High", "3 - Moderate", "4 - Low"]
PRIORITY_BY_SEV = {"1 - Critical": "P1", "2 - High": "P2", "3 - Moderate": "P3", "4 - Low": "P4"}

RESOLUTION_MINUTES = {
    "Database": (45, 300), "Middleware": (30, 240), "Identity": (20, 180),
    "Network": (30, 200), "Infrastructure": (40, 320), "Batch": (60, 360),
    "Market Data": (40, 300), "Trade Processing": (30, 240), "Vendor": (120, 1440),
    "Application": (30, 260), "Security": (60, 720),
}

TROUBLESHOOTING_SNIPPETS = [
    "Checked application logs for the reported error window (read-only).",
    "Compared error timestamps with the latest deployment schedule.",
    "Reviewed monitoring dashboards for CPU, memory and queue depth (read-only).",
    "Asked the requester for screenshots and the exact failure time.",
    "Verified whether the issue affects one user or the whole user group.",
    "Correlated the error with recent configuration changes.",
]

BUSINESS_IMPACTS = [
    "Advisors unable to complete client reviews",
    "Client-facing statements delayed",
    "Back-office processing delayed before cut-off",
    "Limited impact - single team affected",
    "Valuation cycle at risk",
    "Client transactions pending confirmation",
]


def _typo(text: str, rng: random.Random) -> str:
    """Corrupt a small share of words to simulate real-world misspellings."""
    words = text.split()
    out = []
    touched = False
    for w in words:
        key = w.strip(",.:;()").lower()
        if not touched and key in TYPO_MAP and rng.random() < 0.5:
            out.append(w.replace(key, TYPO_MAP[key]))
            touched = True
        else:
            out.append(w)
    return " ".join(out)


def _se_for(rng: random.Random, archetype: dict) -> str:
    if archetype["category"] == "Security":
        return "1 - Critical"
    roll = rng.random()
    if archetype["key"] in ("mq_backlog", "payment_stuck", "cert_expiry", "net_timeout",
                            "auth_401", "trade_delay", "batch_fail", "market_data_missing"):
        return "2 - High" if roll < 0.75 else "3 - Moderate"
    if roll < 0.10:
        return "1 - Critical"
    if roll < 0.45:
        return "2 - High"
    if roll < 0.90:
        return "3 - Moderate"
    return "4 - Low"


def build_ownership_csv() -> None:
    cols = ["team_name", "supported_services", "supported_applications", "common_error_patterns",
            "ownership_description", "escalation_conditions", "restricted_actions",
            "business_hours_or_support_model", "active_status"]
    with open(DATA_DIR / "team_ownership.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=cols)
        writer.writeheader()
        for team in TEAMS:
            writer.writerow({c: team[c] for c in cols})


def build_knowledge_csv() -> None:
    cols = ["article_id", "title", "application_name", "category", "symptoms", "error_codes",
            "diagnostic_steps", "expected_results", "known_root_cause", "resolution_steps",
            "escalation_team", "prerequisites", "risk_level", "source_name", "last_updated",
            "approval_status"]
    with open(DATA_DIR / "knowledge_base.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=cols)
        writer.writeheader()
        for art in KB_ARTICLES:
            writer.writerow({
                "article_id": art["id"],
                "title": art["title"],
                "application_name": art["app"],
                "category": art["category"],
                "symptoms": "|".join(art["symptoms"]),
                "error_codes": "|".join([c for c in art["error_codes"].split("|") if c]),
                "diagnostic_steps": " | ".join(art["diagnostics"]),
                "expected_results": art["expected"],
                "known_root_cause": art["root_cause"],
                "resolution_steps": " | ".join(art["resolution"]),
                "escalation_team": art["escalation"],
                "prerequisites": art["prerequisites"],
                "risk_level": art["risk"],
                "source_name": "SharePoint KDB (simulated)",
                "last_updated": art["updated"],
                "approval_status": art["status"],
            })


def _make_historical(rng: random.Random, start: datetime, end: datetime) -> list[dict]:
    keys = list(WEIGHTS.keys())
    weights = [WEIGHTS[k] for k in keys]
    by_key = {a["key"]: a for a in ARCHETYPES}
    rows: list[dict] = []

    for i in range(1, HISTORICAL_COUNT + 1):
        key = rng.choices(keys, weights=weights, k=1)[0]
        arch = by_key[key]
        created = start + timedelta(seconds=rng.randint(0, int((end - start).total_seconds())))
        sev = _se_for(rng, arch)
        prio = PRIORITY_BY_SEV[sev]
        lo, hi = RESOLUTION_MINUTES.get(arch["category"], (30, 300))
        res_minutes = rng.randint(lo, hi)
        closed = created + timedelta(minutes=res_minutes)

        short = rng.choice(SYMPTOM_VARIANTS).format(symptom=arch["symptom"])
        detail = (
            f"{arch['symptom']}. Environment: {'production' if rng.random() < 0.85 else 'uat'}. "
            f"Reported error code {arch['error_code']} with message: {arch['error_message']}. "
            f"Application {arch['app']}, business service {arch['service']}."
        )
        if rng.random() < 0.35:
            short = _typo(short, rng)
            detail = _typo(detail, rng)

        # Historical assignment practice: most tickets land on Wealth first.
        if arch["final_team"] == "Wealth Application Support":
            initial = "Wealth Application Support"
            reassigned = 0
        elif rng.random() < 0.68:
            initial = "Wealth Application Support"
            reassigned = rng.choice([1, 1, 1, 2, 2, 3])
        else:
            initial = arch["final_team"]
            reassigned = 0

        quality = arch.get("quality")
        if quality is None:
            roll = rng.random()
            quality = "good" if roll < 0.78 else ("partial" if roll < 0.95 else "contradictory")

        status = arch.get("status", "Resolved - Permanent Fix")
        kb_ids = arch.get("kb", [])
        kb = ""
        if kb_ids and rng.random() < 0.80:
            kb = rng.choice(kb_ids)

        rows.append({
            "incident_id": f"HIST-{i:04d}",
            "created_at": created.strftime("%Y-%m-%d %H:%M"),
            "closed_at": closed.strftime("%Y-%m-%d %H:%M"),
            "short_description": short,
            "detailed_description": detail,
            "application_name": arch["app"],
            "business_service": arch["service"],
            "environment": "production" if rng.random() < 0.88 else "uat",
            "error_code": arch["error_code"],
            "error_message": arch["error_message"],
            "severity": sev,
            "priority": prio,
            "business_impact": rng.choice(BUSINESS_IMPACTS),
            "affected_users": rng.randint(1, 1600),
            "initial_assignment_group": initial,
            "final_resolver_team": arch["final_team"],
            "reassignment_count": reassigned,
            "previous_troubleshooting": rng.choice(TROUBLESHOOTING_SNIPPETS),
            "root_cause": arch["root_cause"],
            "resolution_summary": arch["resolution"],
            "resolution_category": arch["category"],
            "resolution_status": status,
            "knowledge_article_id": kb,
            "resolution_time_minutes": res_minutes if status != "Escalated - Under Investigation" else 0,
            "was_wealth_team_correct_owner": arch.get("wealth_correct", "no"),
            "historical_record_quality": quality,
            "data_label": SYNTHETIC_LABEL,
        })

    # Duplicate incidents: same issue re-raised by different requesters.
    dup_sources = rng.sample(rows, 10)
    for n, src in enumerate(dup_sources, start=1):
        dup = dict(src)
        dup["incident_id"] = f"HIST-9{n:03d}"
        created = datetime.strptime(src["created_at"], "%Y-%m-%d %H:%M") + timedelta(hours=3)
        dup["created_at"] = created.strftime("%Y-%m-%d %H:%M")
        dup["closed_at"] = (created + timedelta(minutes=45)).strftime("%Y-%m-%d %H:%M")
        dup["short_description"] = "Duplicate of " + src["incident_id"] + ": " + src["short_description"]
        dup["detailed_description"] = "Raised again by another requester. " + src["detailed_description"]
        rows.append(dup)

    rows.sort(key=lambda r: r["created_at"])
    return rows


def build_historical_csv() -> list[dict]:
    rng = random.Random(SEED)
    end = datetime.now().replace(hour=18, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=HISTORY_DAYS)
    rows = _make_historical(rng, start, end)

    cols = ["incident_id", "created_at", "closed_at", "short_description", "detailed_description",
            "application_name", "business_service", "environment", "error_code", "error_message",
            "severity", "priority", "business_impact", "affected_users", "initial_assignment_group",
            "final_resolver_team", "reassignment_count", "previous_troubleshooting", "root_cause",
            "resolution_summary", "resolution_category", "resolution_status", "knowledge_article_id",
            "resolution_time_minutes", "was_wealth_team_correct_owner", "historical_record_quality",
            "data_label"]
    with open(DATA_DIR / "historical_incidents.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def build_incoming_csv() -> list[dict]:
    rng = random.Random(SEED + 1)
    by_key = {a["key"]: a for a in ARCHETYPES}
    now = datetime.now()
    cols = ["incident_id", "created_at", "short_description", "detailed_description",
            "application_name", "business_service", "environment", "error_code", "error_message",
            "severity", "priority", "business_impact", "affected_users", "current_assignment_group",
            "requester_role", "source", "status", "demo_tag", "data_label"]
    rows: list[dict] = []

    for demo in DEMO_INCIDENTS:
        rows.append({
            "incident_id": demo["incident_id"],
            "created_at": (now - timedelta(minutes=rng.randint(5, 400))).strftime("%Y-%m-%d %H:%M"),
            "short_description": demo["short_description"],
            "detailed_description": demo["detailed_description"],
            "application_name": demo["application_name"],
            "business_service": demo["business_service"],
            "environment": demo["environment"],
            "error_code": demo["error_code"],
            "error_message": demo["error_message"],
            "severity": demo["severity"],
            "priority": demo["priority"],
            "business_impact": demo["business_impact"],
            "affected_users": demo["affected_users"],
            "current_assignment_group": "Wealth Application Support",
            "requester_role": "Service Desk",
            "source": "mock_itsm",
            "status": "new",
            "demo_tag": demo["tag"],
            "data_label": SYNTHETIC_LABEL,
        })

    pool = [k for k in WEIGHTS if k != "sec_burst"]
    for i in range(EXTRA_INCOMING_COUNT):
        arch = by_key[rng.choice(pool)]
        sev = _se_for(rng, arch)
        rows.append({
            "incident_id": f"INC-{2000 + i}",
            "created_at": (now - timedelta(minutes=rng.randint(10, 2600))).strftime("%Y-%m-%d %H:%M"),
            "short_description": rng.choice(SYMPTOM_VARIANTS).format(symptom=arch["symptom"]),
            "detailed_description": (
                f"{arch['symptom']}. Application {arch['app']}, service {arch['service']}. "
                f"Reported error code {arch['error_code']} with message: {arch['error_message']}."
            ),
            "application_name": arch["app"],
            "business_service": arch["service"],
            "environment": "production",
            "error_code": arch["error_code"],
            "error_message": arch["error_message"],
            "severity": sev,
            "priority": PRIORITY_BY_SEV[sev],
            "business_impact": rng.choice(BUSINESS_IMPACTS),
            "affected_users": rng.randint(1, 800),
            "current_assignment_group": "Wealth Application Support",
            "requester_role": rng.choice(["Service Desk", "Relationship Manager", "Operations Analyst"]),
            "source": "mock_itsm",
            "status": "new",
            "demo_tag": "",
            "data_label": SYNTHETIC_LABEL,
        })

    with open(DATA_DIR / "incoming_incidents.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def build_scenarios_csv() -> None:
    cols = ["scenario_id", "category", "short_description", "detailed_description",
            "application_name", "business_service", "environment", "error_code", "error_message",
            "severity", "priority", "business_impact", "affected_users", "current_assignment_group",
            "expected_routing", "expected_team_set", "expected_confidence_behavior",
            "required_safety_behavior", "expected_evidence", "expected_troubleshooting",
            "evaluation_criteria"]
    with open(DATA_DIR / "test_scenarios.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=cols)
        writer.writeheader()
        for sc in SCENARIOS:
            writer.writerow({c: sc[c] for c in cols})


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    build_ownership_csv()
    build_knowledge_csv()
    historical = build_historical_csv()
    incoming = build_incoming_csv()
    build_scenarios_csv()

    months = sorted({r["created_at"][:7] for r in historical})
    print(f"historical_incidents.csv : {len(historical)} rows ({len(months)} months: {months[0]}..{months[-1]})")
    print(f"incoming_incidents.csv   : {len(incoming)} rows ({len(DEMO_INCIDENTS)} demo-tagged)")
    print(f"knowledge_base.csv       : {len(KB_ARTICLES)} articles "
          f"({sum(1 for a in KB_ARTICLES if a['status'] == 'approved')} approved)")
    print(f"team_ownership.csv       : {len(TEAMS)} teams")
    print(f"test_scenarios.csv       : {len(SCENARIOS)} scenarios")
    print("All records are labelled SYNTHETIC DEMO DATA.")


if __name__ == "__main__":
    main()
