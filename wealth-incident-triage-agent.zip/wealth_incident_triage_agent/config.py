"""Central configuration for the Wealth Incident Triage Agent POC.

All values can be overridden with environment variables (see .env.example).
No secrets are stored in this file.
"""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATABASE_DIR = BASE_DIR / "database"
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"
REPORTS_DIR = BASE_DIR / "reports"

# ---------------------------------------------------------------------------
# Datasets
# ---------------------------------------------------------------------------
HISTORICAL_CSV = DATA_DIR / "historical_incidents.csv"
INCOMING_CSV = DATA_DIR / "incoming_incidents.csv"
KNOWLEDGE_CSV = DATA_DIR / "knowledge_base.csv"
OWNERSHIP_CSV = DATA_DIR / "team_ownership.csv"
SCENARIOS_CSV = DATA_DIR / "test_scenarios.csv"

DATABASE_PATH = DATABASE_DIR / "triage.db"
SCHEMA_PATH = DATABASE_DIR / "schema.sql"

# Import limits (CSV import guard rails)
MAX_CSV_ROWS = int(os.environ.get("TRIAGE_MAX_CSV_ROWS", "20000"))
MAX_CSV_BYTES = int(os.environ.get("TRIAGE_MAX_CSV_BYTES", str(10 * 1024 * 1024)))

# ---------------------------------------------------------------------------
# Business baselines (illustrative demo defaults, configurable at runtime)
# ---------------------------------------------------------------------------
BASELINE_MANUAL_MINUTES = int(os.environ.get("TRIAGE_BASELINE_MINUTES", "120"))
EFFECT_REDUCTION_SCENARIOS = {
    "conservative": 0.25,
    "expected": 0.50,
    "optimistic": 0.70,
}
HISTORY_WINDOW_DAYS = 183  # ~six months of historical evidence

# ---------------------------------------------------------------------------
# Confidence policy (demonstration thresholds, NOT validated production values)
# ---------------------------------------------------------------------------
HIGH_CONFIDENCE_MIN = float(os.environ.get("TRIAGE_HIGH_CONFIDENCE", "80"))
MEDIUM_CONFIDENCE_MIN = float(os.environ.get("TRIAGE_MEDIUM_CONFIDENCE", "60"))

TOP_HISTORY_MATCHES = 5
TOP_KB_MATCHES = 3

# ---------------------------------------------------------------------------
# Matching weights (transparent, documented heuristic - not a calibrated model)
# ---------------------------------------------------------------------------
MATCH_WEIGHTS = {
    "tfidf": 0.45,        # cosine similarity of the normalized text
    "error_code": 0.20,   # exact / partial error-code agreement
    "application": 0.15,  # same application or same business service
    "outcome": 0.10,      # successful, permanent resolutions score higher
    "recency": 0.10,      # newer records are more relevant to current ownership
}
RECENCY_HALF_LIFE_DAYS = 120

# ---------------------------------------------------------------------------
# LLM adapter (optional - the POC runs fully offline without it)
# ---------------------------------------------------------------------------
LLM_API_KEY = os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY") or ""
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
LLM_MODEL = os.environ.get("LLM_MODEL", "gpt-4o-mini")
LLM_TIMEOUT_SECONDS = int(os.environ.get("LLM_TIMEOUT_SECONDS", "30"))
LLM_ENABLED = os.environ.get("TRIAGE_LLM_ENABLED", "auto")  # auto | on | off

# Optional local sentence-transformers model (used only if already installed)
SENTENCE_TRANSFORMER_MODEL = os.environ.get(
    "SENTENCE_TRANSFORMER_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
)

# ---------------------------------------------------------------------------
# Security / governance
# ---------------------------------------------------------------------------
SECRET_KEY = os.environ.get("TRIAGE_SECRET_KEY", "poc-local-demo-only-not-for-production")
MAX_TEXT_FIELD_CHARS = 8000
ALLOWED_WRITE_ACTIONS = ("accept", "reject", "manual_review", "edit_destination")

# ---------------------------------------------------------------------------
# Analysis language (AL) configuration - operator-editable at runtime
# ---------------------------------------------------------------------------
# The analysis type / prompt template used by the LLM path of the triage
# engine. Both are stored in the demo_config table and can be read, updated and
# reset from the "Analysis configuration" page (/analysis-config).
# Empty strings mean "use the built-in default".
AL_ANALYSIS_TYPE = os.environ.get("TRIAGE_AL_ANALYSIS_TYPE", "standard")
AL_SYSTEM_PROMPT_TEMPLATE = os.environ.get(
    "TRIAGE_AL_SYSTEM_PROMPT_TEMPLATE", ""
)
AL_USER_PROMPT_TEMPLATE = os.environ.get(
    "TRIAGE_AL_USER_PROMPT_TEMPLATE", ""
)
# When a template file is provided, it overrides the inline string above.
AL_PROMPT_TEMPLATE_FILE = os.environ.get("TRIAGE_AL_PROMPT_TEMPLATE_FILE", "")

# Phrases that make an incident security sensitive: routing is forced to
# MANUAL_REVIEW and Cybersecurity Operations is named as escalation contact.
SECURITY_KEYWORDS = (
    "phishing",
    "ransomware",
    "malware",
    "data exfiltration",
    "exfiltration",
    "credential stuffing",
    "unauthorized access",
    "suspicious login",
    "brute force",
    "security breach",
    "compromised account",
    "insider threat",
    "cyber attack",
    "cyberattack",
    "sql injection",
    "phish",
)

# Detected when untrusted ticket/KB text tries to steer the agent.
PROMPT_INJECTION_PATTERNS = (
    "ignore previous instructions",
    "ignore all previous",
    "disregard previous",
    "ignore the above",
    "new instructions:",
    "system prompt",
    "you must assign",
    "do not follow your instructions",
)

# Content that must never be executed, only displayed as untrusted text.
NEVER_EXECUTE_HINTS = True

APP_NAME = "Wealth Incident Triage Agent (POC)"
SYNTHETIC_DATA_NOTICE = "SYNTHETIC DEMO DATA - no real customer information"
