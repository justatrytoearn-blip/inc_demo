-- ---------------------------------------------------------------------------
-- Wealth Incident Triage Agent POC - SQLite schema
-- Demo state database: synthetic dataset mirrors, triage results, audit log.
-- ---------------------------------------------------------------------------
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS team_ownership (
    team_name                TEXT PRIMARY KEY,
    supported_services       TEXT NOT NULL DEFAULT '',
    supported_applications   TEXT NOT NULL DEFAULT '',
    common_error_patterns    TEXT NOT NULL DEFAULT '',
    ownership_description    TEXT NOT NULL DEFAULT '',
    escalation_conditions    TEXT NOT NULL DEFAULT '',
    restricted_actions      TEXT NOT NULL DEFAULT '',
    business_hours_or_support_model TEXT NOT NULL DEFAULT '',
    active_status            TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS knowledge_articles (
    article_id        TEXT PRIMARY KEY,
    title             TEXT NOT NULL,
    application_name  TEXT NOT NULL DEFAULT '',
    category          TEXT NOT NULL DEFAULT '',
    symptoms          TEXT NOT NULL DEFAULT '',
    error_codes       TEXT NOT NULL DEFAULT '',
    diagnostic_steps  TEXT NOT NULL DEFAULT '',
    expected_results  TEXT NOT NULL DEFAULT '',
    known_root_cause  TEXT NOT NULL DEFAULT '',
    resolution_steps  TEXT NOT NULL DEFAULT '',
    escalation_team   TEXT NOT NULL DEFAULT '',
    prerequisites     TEXT NOT NULL DEFAULT '',
    risk_level        TEXT NOT NULL DEFAULT 'low',
    source_name       TEXT NOT NULL DEFAULT 'SharePoint (simulated)',
    last_updated      TEXT NOT NULL DEFAULT '',
    approval_status   TEXT NOT NULL DEFAULT 'approved'
);

CREATE TABLE IF NOT EXISTS historical_incidents (
    incident_id                TEXT PRIMARY KEY,
    created_at                 TEXT NOT NULL,
    closed_at                  TEXT NOT NULL DEFAULT '',
    short_description          TEXT NOT NULL,
    detailed_description       TEXT NOT NULL DEFAULT '',
    application_name           TEXT NOT NULL DEFAULT '',
    business_service           TEXT NOT NULL DEFAULT '',
    environment                TEXT NOT NULL DEFAULT 'production',
    error_code                 TEXT NOT NULL DEFAULT '',
    error_message              TEXT NOT NULL DEFAULT '',
    severity                   TEXT NOT NULL DEFAULT '3 - Moderate',
    priority                   TEXT NOT NULL DEFAULT 'P3',
    business_impact            TEXT NOT NULL DEFAULT '',
    affected_users             INTEGER NOT NULL DEFAULT 0,
    initial_assignment_group   TEXT NOT NULL DEFAULT '',
    final_resolver_team        TEXT NOT NULL DEFAULT '',
    reassignment_count         INTEGER NOT NULL DEFAULT 0,
    previous_troubleshooting   TEXT NOT NULL DEFAULT '',
    root_cause                 TEXT NOT NULL DEFAULT '',
    resolution_summary         TEXT NOT NULL DEFAULT '',
    resolution_category        TEXT NOT NULL DEFAULT '',
    resolution_status          TEXT NOT NULL DEFAULT '',
    knowledge_article_id       TEXT NOT NULL DEFAULT '',
    resolution_time_minutes    INTEGER NOT NULL DEFAULT 0,
    was_wealth_team_correct_owner TEXT NOT NULL DEFAULT '',
    historical_record_quality  TEXT NOT NULL DEFAULT 'good',
    data_label                 TEXT NOT NULL DEFAULT 'SYNTHETIC DEMO DATA'
);

CREATE TABLE IF NOT EXISTS incoming_incidents (
    incident_id            TEXT PRIMARY KEY,
    created_at             TEXT NOT NULL,
    short_description      TEXT NOT NULL,
    detailed_description   TEXT NOT NULL DEFAULT '',
    application_name       TEXT NOT NULL DEFAULT '',
    business_service       TEXT NOT NULL DEFAULT '',
    environment            TEXT NOT NULL DEFAULT 'production',
    error_code             TEXT NOT NULL DEFAULT '',
    error_message          TEXT NOT NULL DEFAULT '',
    severity               TEXT NOT NULL DEFAULT '3 - Moderate',
    priority               TEXT NOT NULL DEFAULT 'P3',
    business_impact        TEXT NOT NULL DEFAULT '',
    affected_users         INTEGER NOT NULL DEFAULT 0,
    current_assignment_group TEXT NOT NULL DEFAULT 'Wealth Application Support',
    requester_role         TEXT NOT NULL DEFAULT '',
    source                 TEXT NOT NULL DEFAULT 'csv',
    status                 TEXT NOT NULL DEFAULT 'new',
    demo_tag               TEXT NOT NULL DEFAULT '',
    data_label             TEXT NOT NULL DEFAULT 'SYNTHETIC DEMO DATA'
);

CREATE TABLE IF NOT EXISTS triage_results (
    incident_id          TEXT PRIMARY KEY,
    analyzed_at          TEXT NOT NULL,
    recommendation       TEXT NOT NULL,
    proposed_team        TEXT NOT NULL DEFAULT '',
    secondary_team       TEXT NOT NULL DEFAULT '',
    team_confidence      REAL NOT NULL DEFAULT 0,
    match_confidence     REAL NOT NULL DEFAULT 0,
    kb_confidence        REAL NOT NULL DEFAULT 0,
    band                 TEXT NOT NULL DEFAULT 'low',
    summary              TEXT NOT NULL DEFAULT '',
    troubleshooting      TEXT NOT NULL DEFAULT '',
    ticket_update        TEXT NOT NULL DEFAULT '',
    handover             TEXT NOT NULL DEFAULT '',
    evidence             TEXT NOT NULL DEFAULT '[]',
    analysis_json        TEXT NOT NULL DEFAULT '{}',
    analysis_latency_ms  INTEGER NOT NULL DEFAULT 0,
    llm_provider         TEXT NOT NULL DEFAULT 'rule_based_fallback',
    status               TEXT NOT NULL DEFAULT 'pending_approval',
    operator_decision    TEXT NOT NULL DEFAULT '',
    operator_team        TEXT NOT NULL DEFAULT '',
    operator_note        TEXT NOT NULL DEFAULT '',
    decided_at           TEXT NOT NULL DEFAULT '',
    simulated_action     TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS template_uploads (
    upload_id          TEXT PRIMARY KEY,
    upload_type        TEXT NOT NULL DEFAULT 'incident',   -- 'incident' | 'ownership'
    file_name          TEXT NOT NULL,
    file_size_bytes    INTEGER NOT NULL DEFAULT 0,
    mime_type          TEXT NOT NULL DEFAULT '',
    parsed_rows        INTEGER NOT NULL DEFAULT 0,
    errors             TEXT NOT NULL DEFAULT '[]',
    status             TEXT NOT NULL DEFAULT 'processed',  -- processed | rejected | parsing_failed
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS kb_docs (
    doc_id             TEXT PRIMARY KEY,
    file_name          TEXT NOT NULL,
    mime_type          TEXT NOT NULL DEFAULT '',
    byte_size          INTEGER NOT NULL DEFAULT 0,
    title              TEXT NOT NULL DEFAULT '',
    team               TEXT NOT NULL DEFAULT '',       -- first-level owner of this SOP
    content            TEXT NOT NULL DEFAULT '',       -- plain-text extraction (PDF/txt/md)
    raw_path           TEXT NOT NULL DEFAULT '',       -- served path for the demo upload folder
    approved           INTEGER NOT NULL DEFAULT 0,     -- 1 = operator marked OK for first-level use
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sop_steps (
    step_id            TEXT PRIMARY KEY,
    doc_id             TEXT NOT NULL REFERENCES kb_docs(doc_id),
    position           INTEGER NOT NULL DEFAULT 0,
    label              TEXT NOT NULL DEFAULT '',       -- e.g. "Step 1 - Confirm", "Diagnosis", "Action"
    headline           TEXT NOT NULL DEFAULT '',       -- short heading
    body               TEXT NOT NULL DEFAULT '',       -- free-text step detail
    status             TEXT NOT NULL DEFAULT 'pending' -- pending | used | superseded
);

CREATE INDEX IF NOT EXISTS idx_sop_doc ON sop_steps(doc_id);

CREATE TABLE IF NOT EXISTS audit_log (
    log_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_time       TEXT NOT NULL,
    event_type       TEXT NOT NULL,
    incident_id      TEXT NOT NULL DEFAULT '',
    actor            TEXT NOT NULL DEFAULT 'system',
    method           TEXT NOT NULL DEFAULT '',
    evidence_refs    TEXT NOT NULL DEFAULT '[]',
    recommendation   TEXT NOT NULL DEFAULT '',
    confidence       TEXT NOT NULL DEFAULT '{}',
    human_decision   TEXT NOT NULL DEFAULT '',
    final_action     TEXT NOT NULL DEFAULT '',
    notes            TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS demo_config (
    config_key   TEXT PRIMARY KEY,
    config_value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_hist_created ON historical_incidents(created_at);
CREATE INDEX IF NOT EXISTS idx_hist_app ON historical_incidents(application_name);
CREATE INDEX IF NOT EXISTS idx_incoming_created ON incoming_incidents(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(event_time);
