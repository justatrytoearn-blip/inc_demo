# Wealth Incident Triage Agent (POC)

A working proof-of-concept that reads an IT incident ticket, decides **which team should
own it**, explains **why**, and drafts the **first-level troubleshooting steps** for the
analyst to approve.

Everything is local. No cloud account, no database server, no internet connection is
required. All data is **synthetic demo data** — no real customer information is included.

---

## What it does

For a single incident the agent produces a report containing:

| Output | Meaning |
|---|---|
| **Routing recommendation** | `auto_accept` (confident), `manual_review` (unsure) or `escalate` |
| **Proposed team** + secondary team | e.g. Wealth Application Support, with a fallback contact |
| **Confidence score + band** | `high` / `medium` / `low`, computed from transparent weighted evidence |
| **Evidence** | The historical tickets, knowledge articles and error-code matches that drove the decision |
| **Sections A–E troubleshooting** | Triage checks, diagnostics, remediation, verification, escalation criteria |
| **Ticket update text** | A ready-to-paste customer-facing note |
| **Handover note** | What the receiving team needs to know |
| **Safety flags** | Outdated KB warning, draft-KB rejection, security escalation, access-control refusal, destructive-action guard |

Every analysis, acceptance and decline is written to an **audit log**.

The agent **abstains** (routes to `manual_review`) when the evidence is weak, so a human
always makes the final call. Nothing is ever written back to a real ITSM tool — the
write-back is mocked.

---

## Requirements

- **Python 3.10 or newer** (developed and tested on 3.14)
- ~200 MB of disk space for dependencies
- No internet access needed at runtime (only during `pip install`)

The only Python packages used are listed in `requirements.txt`:
`flask`, `pandas`, `scikit-learn`, `pytest`, `python-dotenv`.

---

## Install

### Windows (PowerShell)

```powershell
# 1. Go into the project folder
cd wealth_incident_triage_agent

# 2. Create a virtual environment
python -m venv .venv

# 3. Install dependencies
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

> **If step 2 says** *"Python was not found; run without arguments to install from the
> Microsoft Store"*, Python is not installed on your machine (that message is only a
> Windows shortcut). Install it once from <https://www.python.org/downloads/> and tick
> **"Add python.exe to PATH"** during setup, then reopen PowerShell and start again.
>
> The `python` command is **not** what runs this app. Once the `.venv` exists you always
> call `.venv\Scripts\python.exe` (or activate the venv first, see below).

### macOS / Linux

```bash
cd wealth_incident_triage_agent
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

### Optional: configuration file

The app runs with sensible defaults and needs **no** configuration. To customise it:

```bash
cp .env.example .env      # Windows: copy .env.example .env
```

Then edit `.env`. The most useful settings:

| Variable | Default | Purpose |
|---|---|---|
| `TRIAGE_PORT` | `5000` | Port the web server listens on |
| `TRIAGE_SECRET_KEY` | dev value | Flask session secret |
| `TRIAGE_LLM_ENABLED` | `auto` | `auto` = use the LLM only if a key exists, `on` = always try, `off` = never |
| `LLM_API_KEY` | *(empty)* | Any OpenAI-compatible API key; empty means use the built-in offline writer |
| `LLM_BASE_URL` | `https://api.openai.com/v1` | Point at OpenAI, Azure OpenAI, Ollama, LM Studio, etc. |
| `LLM_MODEL` | `gpt-4o-mini` | Model name |
| `TRIAGE_BASELINE_MINUTES` | `120` | Manual minutes per ticket used for the savings calculation |
| `TRIAGE_HIGH_CONFIDENCE` / `TRIAGE_MEDIUM_CONFIDENCE` | `80` / `60` | Confidence band thresholds |

**The LLM is optional.** With no key the app uses a deterministic rule-based writer that
always produces the same output for the same ticket. That means the demo and the
evaluation numbers are fully reproducible offline.

---

## Run it

### Windows (PowerShell)

```powershell
cd wealth_incident_triage_agent
.venv\Scripts\python.exe app.py
```

### macOS / Linux

```bash
cd wealth_incident_triage_agent
.venv/bin/python app.py
```

### Shortcut: activate the venv once per terminal window

```powershell
# Windows
.venv\Scripts\Activate.ps1
python app.py
```

```bash
# macOS / Linux
source .venv/bin/activate
python app.py
```

> If PowerShell blocks the activation script, run
> `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that window first.

You should see:

```
 * Running on http://127.0.0.1:5000
```

Open **<http://127.0.0.1:5000>** in a browser. Stop the server with `Ctrl + C`.

### First run

On the first start the app creates `database/triage.db` automatically and loads the CSV
datasets into it. This takes about a second. Subsequent starts reuse the existing
database. To start completely fresh, stop the server and delete `database/triage.db` —
it will be rebuilt from the CSVs on the next start.

**Included demo data**

| Dataset | File | Rows |
|---|---|---|
| Open incident queue | `data/incoming_incidents.csv` | 28 |
| Historical resolved incidents | `data/historical_incidents.csv` | 350 |
| Knowledge articles | `data/knowledge_base.csv` | 49 |
| Team ownership matrix | `data/team_ownership.csv` | 10 teams |
| Labelled evaluation scenarios | `data/test_scenarios.csv` | 42 |

---

## How to use it

The navigation bar walks through the whole workflow left to right. Five minutes is enough
to see everything.

### 1. Dashboard — `http://127.0.0.1:5000/`

Shows how many rows loaded from each dataset, the current savings estimate, the most
recent analyses and the open queue. It is the "is everything wired up?" page; if the
dataset table has non-zero numbers, you are ready.

### 2. Analyse an incident — *Open queue* → **Analyse**

1. Click **Open queue** to see the 28 open tickets.
2. Click **Analyse** on any row (or paste an incident ID into the Analyse page).
3. Press **Analyse**. You get: recommendation, proposed team, confidence badge, the
   evidence list, troubleshooting sections **A–E**, the ticket update and the handover note.
4. Choose **Accept / approve**, **Send to manual review** or **Override destination team**.

The same incident can be re-analysed at any time; the newest result wins.

### 3. Create an incident from free text — **New incident (free text)**

Fill in just an application, an error code and a plain-English description; the form
builds a full ticket and analyses it immediately.

Try this one — it should route to **Wealth Application Support** with **medium** confidence:

| Field | Value |
|---|---|
| Application | `PortfolioPilot` |
| Error code | `WM-CFG-001` |
| Description | `feature flag valuation_v2 enabled on 2 of 6 nodes` |

### 4. Run the evaluation — `http://127.0.0.1:5000/evaluation`

Press **Run all 42 labeled scenarios**. The page reports:

- overall pass rate
- routing accuracy
- confidence-band compliance
- evidence compliance
- sections A–E troubleshooting compliance
- safety compliance (outdated KB, draft KB, security escalation, access control, destructive actions)

Labels are stripped from the payload before analysis, so the engine cannot cheat by
reading the expected answer. Expected result on the bundled data: **42/42, 100 %**.

The same run is available from the command line and writes reports to `reports/`:

```powershell
.venv\Scripts\python.exe scripts\run_evaluation.py
```

This produces `reports/evaluation_report.md` and `reports/evaluation_results.json`.

### 5. Knowledge base and SOP upload — **KB / SOP upload**

Upload a `.txt`, `.md`, `.docx` or `.pdf` document, choose the owning team and tick
**approved**, then submit. The document is indexed and the page shows the parsed
**Steps**. Ticking **approved** matters: a document that is *not* approved is rejected by
the engine during analysis and the report carries a `draft_kb_rejected` flag — that
behaviour is intentional and is one of the graded safety scenarios.

### 6. Knowledge, Ownership and Template pages

- **Knowledge base** — the 49 indexed articles the retriever searches.
- **Ownership** — the authoritative routing matrix (10 teams, their applications, common
  error patterns, escalation rules and support hours). This is what the router trusts.
- **Template & import** — download the two CSV templates (historical incidents and
  ownership matrix), then upload filled-in versions to replace/extend the reference data.
  **Template status** lists past imports.
- **AL config** — change the narrative *analysis type* (`standard`, `concise`, `verbose`,
  `manual-first`) or paste your own prompt template, then re-analyse a ticket to see the
  report style change. **Reset** restores the defaults.

### 7. Audit — `http://127.0.0.1:5000/audit`

Chronological log of every analysis, acceptance and decline, with the evidence
references and confidence that were used. This is the page to show a governance reviewer.

---

## Project structure

```
wealth_incident_triage_agent/
├── app.py                    # Flask app: all routes and page controllers
├── config.py                 # every tunable value and threshold, env-overridable
├── requirements.txt
├── .env.example              # configuration template
├── data/                     # synthetic CSV datasets + import templates
├── database/
│   ├── schema.sql            # SQLite schema (created idempotently on start)
│   └── triage.db             # generated on first run, git-ignored
├── services/
│   ├── loader.py             # CSV guards, SQLite bootstrap, persistence
│   ├── matcher.py            # similarity + error-code + recency matching
│   ├── knowledge.py          # KB retriever
│   ├── recommendation.py     # the decision engine: routing, confidence, safety flags
│   ├── llm_adapter.py        # optional LLM call + deterministic rule-based fallback
│   ├── triage.py             # orchestrates one analysis end to end
│   ├── metrics.py            # savings estimate
│   └── audit.py              # audit log
├── integrations/             # mocked ITSM and SharePoint clients (no real calls)
├── scripts/
│   ├── run_evaluation.py     # CLI evaluation runner
│   ├── generate_sample_data.py
│   └── *_defs.py             # synthetic data definitions
├── templates/                # Jinja2 pages
├── static/                   # CSS and JS
└── reports/                  # evaluation output (last run is committed as evidence)
```

---

## How the decision is made (short version)

1. **Normalise** the ticket text, pull out error codes, application and service.
2. **Match** it against the 350 historical incidents and 49 knowledge articles using
   TF-IDF cosine similarity, plus exact/partial error-code agreement, application overlap,
   resolution outcome and recency.
3. **Score** the candidate teams against the ownership matrix with fixed, documented
   weights (see `config.MATCH_WEIGHTS`).
4. **Apply safety overrides** — security keywords force `manual_review` +
   Cybersecurity Operations and suppress any account action; unapproved KB documents are
   rejected; destructive actions require an approved change record; access-control bypass
   requests are refused; prompt-injection phrases in ticket text are treated as untrusted
   content and flagged.
5. **Abstain** when the evidence is too thin or the top two teams are too close, and say
   which tickets or documents a human should look at.
6. **Write the narrative** — via the LLM if configured, otherwise the deterministic
   fallback — producing sections A–E, the ticket update and the handover.

Every number on screen traces back to a row in the audit log and a matched record.

---

## Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `Python was not found; run without arguments to install from the Microsoft Store` | Python isn't installed. Install it from python.org with "Add to PATH", or just use the project venv: `.venv\Scripts\python.exe app.py` |
| `ModuleNotFoundError: No module named 'flask'` | Dependencies weren't installed into the interpreter you ran. Use `.venv\Scripts\python.exe -m pip install -r requirements.txt` and then `.venv\Scripts\python.exe app.py` |
| `Activate.ps1 cannot be loaded because running scripts is disabled` | Run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that PowerShell window |
| `OSError: [WinError 10048] address already in use` | Port 5000 is taken. Start with another port: `$env:TRIAGE_PORT=5001; .venv\Scripts\python.exe app.py` |
| Pages load but the queue is empty | The database is incomplete. Stop the server, delete `database/triage.db`, restart |
| "LLM provider" shows `rule_based_fallback` | Expected. The LLM is optional and off unless `LLM_API_KEY` is set in `.env` |
| Evaluation shows less than 42/42 | `data/test_scenarios.csv` or `data/knowledge_base.csv` was edited. Restore the originals from git |

---

## Commit it to Git

The repository does not need to contain the virtual environment, the database or any
logs — they are all covered by `.gitignore` and regenerate. To publish the project:

```bash
git init
git add .
git commit -m "Wealth Incident Triage Agent POC"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

What gets committed: source, HTML templates, CSS/JS, the CSV datasets, `schema.sql`,
`.env.example`, the last evaluation report and this README. What does not: `.venv/`,
`database/triage.db`, `__pycache__/`, `*.log`, `.env`.

Anyone who clones it only needs steps **Install** → **Run it** above.

---

## Limitations (this is a POC)

- All data is synthetic and the confidence thresholds are demonstration values, not
  validated production calibration.
- The similarity model is TF-IDF, not a trained embeddings model. It is transparent and
  reproducible, and that is the trade-off chosen here.
- ITSM and SharePoint integrations are **mocked**. No ticket is ever created, updated or
  closed in a real system.
- Savings figures are an estimate from `TRIAGE_BASELINE_MINUTES` and the confidence-band
  distribution, not a measured outcome.
- Single-user local demo: SQLite file storage, Flask development server, no
  authentication. Do not expose it on an untrusted network.
