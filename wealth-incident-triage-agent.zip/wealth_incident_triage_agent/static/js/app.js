// Demo walkthrough for the Wealth Incident Triage Agent POC.
// Idempotent: safe to run repeatedly.

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function copy(text, msg) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => flash(msg || "Copied", "ok"));
  } else {
    flash(msg || "Copy not supported", "muted");
  }
}

function flash(msg, cls) {
  const el = $('#flash') || (() => {
    const e = document.createElement('div');
    e.id = 'flash';
    e.className = 'muted';
    document.body.appendChild(e);
    return e;
  })();
  el.textContent = msg;
  el.className = 'muted';
  setTimeout(() => { el.textContent = ""; }, 2500);
}

function tab(panel) {
  $$('.tab-button').forEach(t => t.classList.toggle('active', t.dataset.tab === panel));
  $$('.panel').forEach(p => p.classList.toggle('hidden', p.id !== 'tab-' + panel));
}

document.querySelectorAll('.tab-button').forEach(btn => {
  btn.addEventListener('click', () => tab(btn.dataset.tab));
});

document.querySelectorAll('button[data-action]').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action;
    if (action === 'copy') copy(btn.dataset.copy);
    if (action === 'analyze') location.href = '/analyze';
  });
});

// ---- Drag & drop + file upload helpers -------------------------------------
async function uploadFile(form, url, onProgress) {
  const fd = new FormData(form);
  const r = await fetch(url, { method: 'POST', body: fd });
  const j = await r.json();
  if (onProgress) onProgress(r.status, j);
  return j;
}

function enableDropZone(zone) {
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(ev => {
    zone.addEventListener(ev, (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (ev === 'dragenter' || ev === 'dragover') zone.classList.add('drag-over');
      else if (ev === 'dragleave') zone.classList.remove('drag-over');
      else {
        zone.classList.remove('drag-over');
        const file = e.dataTransfer.files && e.dataTransfer.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          zone.textContent = file.name + ' (' + file.size + ' bytes) - valid CSV? JSON? OK to send.';
          flash('Upload ready. Drop the file into the form to send.', 'ok');
        };
        reader.readAsText(file);
      }
    });
  });
}

window.addEventListener('load', () => {
  // Per-page upload drop zones
  ['incidentUpload', 'ownershipUpload', 'kbFile'].forEach(id => {
    const zone = document.getElementById(id);
    if (zone) enableDropZone(zone);
  });
  // Auto-submit when a template file is dropped into a form
  document.querySelectorAll('form[data-upload]').forEach(form => {
    form.addEventListener('submit', (e) => {
      const file = form.querySelector('input[type=file]');
      if (file && file.files.length) {
        e.preventDefault();
        const url = form.dataset.upload;
        uploadFile(form, url, (status, j) => {
          flash(j.ok ? 'Imported ' + (j.parsed_rows||0) + ' rows' : 'Failed: ' + (j.error||j.status), j.ok ? 'ok' : 'fail');
          if (j.ok) location.reload();
        });
      }
    });
  });
});
